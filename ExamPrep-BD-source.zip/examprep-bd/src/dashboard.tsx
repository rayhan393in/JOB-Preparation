import { useMemo, useState } from "react";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  CalendarDays,
  ChartNoAxesCombined,
  ChevronDown,
  Clock3,
  Flame,
  GraduationCap,
  Info,
  LibraryBig,
  Sparkles,
  Target,
  Zap,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import {
  useApp,
  Button,
  dateKey,
  dateLabel,
  LinkButton,
  Empty,
  Heading,
  Select,
} from "./ui";
const demo = [
  { label: "Mon", BCS: 43, EEE: 27 },
  { label: "Tue", BCS: 52, EEE: 38 },
  { label: "Wed", BCS: 47, EEE: 33 },
  { label: "Thu", BCS: 69, EEE: 48 },
  { label: "Fri", BCS: 64, EEE: 45 },
  { label: "Sat", BCS: 82, EEE: 57 },
  { label: "Sun", BCS: 77, EEE: 64 },
];
const demoSessions = [
  {
    subject: "Bangla",
    subtopic: "সমাস (Compound Words)",
    minutes: 45,
    color: "lavender",
    track: "BCS",
  },
  {
    subject: "English",
    subtopic: "Prepositions",
    minutes: 45,
    color: "green",
    track: "BCS",
  },
  {
    subject: "Electrical Machines",
    subtopic: "Transformers",
    minutes: 60,
    color: "gold",
    track: "EEE",
  },
];
function trend(n: number) {
  return Array.from({ length: n }, (_, i) => {
    const d = new Date(Date.now() - 864e5 * (n - 1 - i));
    return {
      key: dateKey(d),
      label: dateLabel(
        d,
        n === 7 ? { weekday: "short" } : { month: "short", day: "numeric" },
      ),
      BCS: null as any,
      EEE: null as any,
    };
  });
}
export function Dashboard({ full = false }: { full?: boolean }) {
  const { user, syllabus, totals, exams, routine, track, language } = useApp();
  const [range, setRange] = useState(7),
    [subject, setSubject] = useState(""),
    [topic, setTopic] = useState("");
  const completed = exams.filter((e) => e.submitted_at),
    eligible = completed.filter(
      (e) =>
        dateKey(e.submitted_at) >=
        dateKey(new Date(Date.now() - (range - 1) * 864e5)),
    );
  const answered = eligible
    .flatMap((e) => e.topics || [])
    .filter(
      (x) =>
        (track === "Both" || x.track === track) &&
        (!subject || x.subject === subject) &&
        (!topic || x.subtopic === topic) &&
        x.outcome !== "Unanswered",
    );
  const realRoutine = routine.filter(
    (r) =>
      r.day === dateKey() &&
      (track === "Both" ||
        syllabus.find((s) => s.id === r.subject)?.track === track),
  );
  const visibleRoutine = routine.filter(
    (r) =>
      (track === "Both" ||
        syllabus.find((s) => s.id === r.subject)?.track === track) &&
      (!subject || r.subject === subject) &&
      (!topic || r.subtopic === topic),
  );
  const sample = !full && !user;
  const answeredCorrect = answered.filter(
    (a) => a.outcome === "Correct",
  ).length;
  const accuracy = answered.length
    ? Math.round((100 * answeredCorrect) / answered.length)
    : null;
  const study = visibleRoutine
    .filter(
      (r) =>
        r.completed &&
        r.day >= dateKey(new Date(Date.now() - (range - 1) * 864e5)),
    )
    .reduce((a, r) => a + r.minutes, 0);
  const streakDays = new Set([
    ...completed
      .filter(
        (e) => track === "Both" || e.track === track || e.track === "Both",
      )
      .map((e) => dateKey(e.submitted_at)),
    ...visibleRoutine.filter((r) => r.completed).map((r) => r.day),
  ]);
  let streak = 0;
  let offset = streakDays.has(dateKey()) ? 0 : 1;
  while (
    streakDays.has(dateKey(new Date(Date.now() - (offset + streak) * 864e5)))
  )
    streak++;
  const chart = useMemo(() => {
    if (sample)
      return range === 7
        ? demo
        : Array.from({ length: range }, (_, i) => ({
            ...demo[i % 7],
            label: trend(range)[i].label,
          }));
    return trend(range).map((d) => {
      for (const t of ["BCS", "EEE"]) {
        const a = eligible
          .filter((e) => dateKey(e.submitted_at) === d.key)
          .flatMap((e) => e.topics)
          .filter(
            (a) =>
              a.track === t &&
              a.outcome !== "Unanswered" &&
              (!subject || a.subject === subject) &&
              (!topic || a.subtopic === topic),
          );
        d[t] = a.length
          ? Math.round(
              (a.filter((q) => q.outcome === "Correct").length / a.length) *
                100,
            )
          : null;
      }
      return d;
    });
  }, [range, sample, exams, subject, topic]);
  const studyDate = new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    timeZone: "Asia/Dhaka",
  }).format(new Date());
  const currentCards = [
    {
      label: "Questions attempted",
      value: sample ? "248" : answered.length,
      sub: sample
        ? "↑ 34 this week"
        : `${answeredCorrect} correct · ${answered.length - answeredCorrect} incorrect`,
      Icon: LibraryBig,
      color: "lavender",
    },
    {
      label: "Overall accuracy",
      value: sample ? "76.4%" : accuracy === null ? "—" : `${accuracy}%`,
      sub: sample ? "↑ 5.2% vs last week" : `${range}-day average`,
      Icon: Target,
      color: "green",
    },
    {
      label: "Study time",
      value: sample ? "18h 30m" : `${Math.floor(study / 60)}h ${study % 60}m`,
      sub: sample ? "↑ 3h 15m this week" : "From completed sessions",
      Icon: Clock3,
      color: "gold",
    },
    {
      label: "Study streak",
      value: sample ? "7 days" : `${streak} ${streak === 1 ? "day" : "days"}`,
      sub: sample ? "Keep the momentum!" : "Study or take an exam",
      Icon: Flame,
      color: "peach",
    },
  ];
  const sessions = sample
    ? demoSessions.filter((s) => track === "Both" || s.track === track)
    : realRoutine.map((r, i) => ({
        ...r,
        subject: syllabus.find((s) => s.id === r.subject)?.name,
        track: syllabus.find((s) => s.id === r.subject)?.track,
        color: ["lavender", "green", "gold"][i % 3],
      }));
  const weak = Object.entries(
    answered.reduce(
      (m, x) => {
        const k = x.subject + "|" + x.subtopic;
        m[k] ??= [0, 0];
        m[k][0]++;
        m[k][1] += +(x.outcome === "Correct");
        return m;
      },
      {} as Record<string, number[]>,
    ) as Record<string, number[]>,
  )
    .map(([k, [n, c]]) => ({ k, n, p: Math.round((100 * c) / n) }))
    .sort((a, b) => a.p - b.p);
  const selected = syllabus.find((s) => s.id === subject);
  const totalQuestions = totals
    .filter((t) => track === "Both" || t.track === track)
    .reduce((n, t) => n + t.count, 0);
  const doneTopics = new Set(
    visibleRoutine
      .filter((r) => r.completed)
      .map((r) => JSON.stringify([r.subject, r.topic, r.subtopic])),
  ).size;
  const totalTopics = syllabus
    .filter((s) => track === "Both" || s.track === track)
    .reduce((n, s) => n + Object.values(s.groups).flat().length, 0);
  const dailyDone = completed.filter(
    (e) =>
      e.mode === "daily" &&
      dateKey(e.submitted_at) === dateKey() &&
      (track === "Both" || e.track === track || e.track === "Both"),
  ).length;
  return (
    <>
      {full ? (
        <Heading
          title="Performance Analytics"
          eyebrow="INSIGHTS"
          subtitle="See what’s improving and where to focus next."
        />
      ) : (
        <>
          <div className="welcome">
            <div>
              <p className="eyebrow">
                <span className="tiny-dot" /> YOUR STUDY WORKSPACE
              </p>
              <h1>
                {language === "bn"
                  ? "প্রস্তুতির ড্যাশবোর্ড"
                  : "Preparation Dashboard"}
              </h1>
              <p className="muted">
                A little progress every day adds up to big results.
              </p>
            </div>
            <span className="date-chip">
              <CalendarDays size={15} />
              {studyDate}
            </span>
          </div>
          <section className="hero">
            <div className="hero-illustration" />
            <div className="hero-content">
              <span className="hero-kicker">
                <Sparkles size={14} /> YOUR PREPARATION JOURNEY
              </span>
              <h2>
                Study with purpose.
                <br />
                <em>Prepare with confidence.</em>
              </h2>
              <p>Your BCS and EEE preparation, all in one place.</p>
              <div className="hero-actions">
                <LinkButton to="daily" variant="cream">
                  Start daily exam
                </LinkButton>
                <a className="hero-link" href="#routine">
                  View study plan <ArrowRight size={15} />
                </a>
              </div>
            </div>
          </section>
        </>
      )}
      <div className="section-bar">
        <div className="section-title">
          {full ? "Activity overview" : "At a glance"}{" "}
          {sample && (
            <span className="demo-chip">
              <span /> Demo data
            </span>
          )}
        </div>
        <label className="range">
          <CalendarDays size={14} />
          <select
            aria-label="Date range"
            value={range}
            onChange={(e) => setRange(+e.target.value)}
          >
            <option value="7">Last 7 days</option>
            <option value="14">Last 14 days</option>
            <option value="30">Last 30 days</option>
          </select>
          <ChevronDown size={13} />
        </label>
      </div>
      {full && (
        <div className="filters panel">
          <Select
            label="Subject"
            value={subject}
            placeholder="All subjects"
            opts={syllabus
              .filter((s) => track === "Both" || s.track === track)
              .map((s) => ({ value: s.id, label: s.name }))}
            onChange={(v) => {
              setSubject(v);
              setTopic("");
            }}
          />
          <Select
            label="Topic"
            value={topic}
            placeholder="All topics"
            opts={Object.values(selected?.groups || {}).flat()}
            onChange={setTopic}
          />
        </div>
      )}
      <div className="metric-grid">
        {currentCards.map(({ label, value, sub, Icon, color }) => (
          <article className="metric panel" key={label}>
            <div className="metric-top">
              <span className={"icon-tile " + color}>
                <Icon size={19} />
              </span>
              <ArrowUpRight size={15} className="metric-arrow" />
            </div>
            <p>{label}</p>
            <strong>{value}</strong>
            <small>{sub}</small>
          </article>
        ))}
      </div>
      <div className="dashboard-grid">
        <section className="panel progress-panel">
          <div className="panel-head">
            <div>
              <h2>Study performance</h2>
              <p>Track how your accuracy changes over time</p>
            </div>
            <span className="icon-tile lavender">
              <ChartNoAxesCombined size={17} />
            </span>
          </div>
          <div className="chart-legend">
            {(track === "Both" || track === "BCS") && (
              <span>
                <i className="legend-plum" /> BCS
              </span>
            )}
            {(track === "Both" || track === "EEE") && (
              <span>
                <i className="legend-gold" /> EEE
              </span>
            )}
          </div>
          <div className="chart">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={chart}
                margin={{ top: 5, right: 14, left: -22, bottom: 1 }}
              >
                <defs>
                  <linearGradient id="area-bcs" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="#78567b" stopOpacity={0.23} />
                    <stop
                      offset="100%"
                      stopColor="#78567b"
                      stopOpacity={0.015}
                    />
                  </linearGradient>
                  <linearGradient id="area-eee" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="#ce9a54" stopOpacity={0.19} />
                    <stop
                      offset="100%"
                      stopColor="#ce9a54"
                      stopOpacity={0.01}
                    />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  stroke="var(--rule)"
                  vertical={false}
                  strokeDasharray="3 4"
                />
                <XAxis
                  dataKey="label"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--muted)", fontSize: 11 }}
                  tickMargin={8}
                  minTickGap={16}
                />
                <YAxis
                  domain={[0, 100]}
                  tickFormatter={(n) => n + "%"}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--muted)", fontSize: 10 }}
                  ticks={[0, 25, 50, 75, 100]}
                />
                <Tooltip
                  formatter={(v: any) => `${v}%`}
                  contentStyle={{
                    background: "var(--panel)",
                    border: "1px solid var(--rule)",
                    borderRadius: 10,
                  }}
                />
                {(track === "Both" || track === "BCS") && (
                  <Area
                    type="monotone"
                    dataKey="BCS"
                    stroke="#79557d"
                    strokeWidth={2.5}
                    fill="url(#area-bcs)"
                    dot={!sample}
                    isAnimationActive={false}
                    connectNulls
                  />
                )}
                {(track === "Both" || track === "EEE") && (
                  <Area
                    type="monotone"
                    dataKey="EEE"
                    stroke="#c58f48"
                    strokeWidth={2.5}
                    fill="url(#area-eee)"
                    dot={!sample}
                    isAnimationActive={false}
                    connectNulls
                  />
                )}
              </AreaChart>
            </ResponsiveContainer>
            {!sample && !answered.length && (
              <span className="chart-empty">
                Take an exam to see your performance here.
              </span>
            )}
          </div>
        </section>
        <section className="panel plan-panel">
          <div className="panel-head">
            <div>
              <h2>{full ? "Topics to improve" : "Today’s study plan"}</h2>
              <p>
                {full
                  ? "Lowest accuracy in this period"
                  : sample
                    ? "Suggested sessions · Demo"
                    : "Your scheduled sessions"}
              </p>
            </div>
            <span className="icon-tile gold">
              <CalendarDays size={17} />
            </span>
          </div>
          {full ? (
            weak.length ? (
              <div className="study-list">
                {weak.slice(0, 5).map((x) => (
                  <div className="study-row" key={x.k}>
                    <div>
                      <strong>{x.k.split("|")[1]}</strong>
                      <small>
                        {syllabus.find((s) => s.id === x.k.split("|")[0])?.name}
                      </small>
                    </div>
                    <b>{x.p}%</b>
                  </div>
                ))}
              </div>
            ) : (
              <Empty title="No topic results yet" />
            )
          ) : sessions.length ? (
            <div className="study-list">
              {sessions.slice(0, 3).map((s, i) => (
                <a href="#routine" className="study-row" key={i}>
                  <span className={"icon-tile " + s.color}>
                    {s.track === "EEE" ? (
                      <Zap size={16} />
                    ) : (
                      <BookOpen size={16} />
                    )}
                  </span>
                  <div>
                    <strong>{s.subtopic}</strong>
                    <small>
                      {s.subject} <span>·</span> {s.track}
                    </small>
                  </div>
                  <b>{s.minutes} min</b>
                </a>
              ))}
            </div>
          ) : (
            <Empty
              title="No sessions today"
              description="Generate a plan based on your preparation track."
            />
          )}
          <div className="plan-footer">
            <LinkButton to={full ? "weakness" : "routine"}>
              {full ? "See weakness recovery" : "View full routine"}
            </LinkButton>
          </div>
        </section>
      </div>
      {!full ? (
        <>
          <div className="section-bar">
            <div className="section-title">Preparation tracks</div>
          </div>
          <div className="track-grid">
            {[
              {
                name: "BCS Preliminary",
                key: "BCS",
                path: "bcs",
                Icon: GraduationCap,
                copy: "10 subjects · 200-mark preliminary syllabus",
                color: "lavender",
              },
              {
                name: "EEE Technical Jobs",
                key: "EEE",
                path: "eee",
                Icon: Zap,
                copy: "15 subjects · Electrical engineering recruitment",
                color: "gold",
              },
            ].map(({ name, key, path, Icon, copy, color }) => (
              <a className="panel track-card" key={key} href={"#" + path}>
                <span className={"icon-tile " + color}>
                  <Icon size={23} />
                </span>
                <div>
                  <h3>{name}</h3>
                  <p>{copy}</p>
                </div>
                <ArrowUpRight size={19} />
              </a>
            ))}
          </div>
          <section
            className="panel dashboard-totals"
            aria-label="Preparation totals"
          >
            {[
              ["Available questions", totalQuestions],
              ["Completed topics", doneTopics],
              ["Pending topics", Math.max(0, totalTopics - doneTopics)],
              ["Daily exams today", dailyDone],
            ].map(([label, value]) => (
              <div key={label}>
                <small>{label}</small>
                <strong>{Number(value).toLocaleString()}</strong>
              </div>
            ))}
          </section>
          <div className="dash-foot">
            <Info size={14} />
            <span>
              {sample
                ? "Demonstration metrics are not your personal results. Take an exam to start tracking progress."
                : `${totals.reduce((n, t) => n + t.count, 0).toLocaleString()} practice and verified questions in the bank.`}
            </span>
          </div>
        </>
      ) : (
        <section className="panel block">
          <h2>Examination history</h2>
          {exams.length ? (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Exam</th>
                    <th>Date</th>
                    <th>Score</th>
                    <th>Accuracy</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {exams
                    .filter(
                      (e) =>
                        track === "Both" ||
                        e.track === track ||
                        e.track === "Both",
                    )
                    .map((e) => (
                      <tr key={e.id}>
                        <td>
                          {e.track} · {e.mode}
                        </td>
                        <td>{dateKey(e.started_at)}</td>
                        <td>
                          {e.submitted_at
                            ? `${e.score} / ${e.total}`
                            : "Not submitted"}
                        </td>
                        <td>{e.submitted_at ? `${e.accuracy}%` : "—"}</td>
                        <td>
                          <LinkButton to={"exam/" + e.id}>
                            {e.submitted_at
                              ? "Results"
                              : new Date(e.ends_at) < new Date()
                                ? "Finalize"
                                : "Resume"}
                          </LinkButton>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          ) : (
            <Empty title="No attempts yet" />
          )}
        </section>
      )}
    </>
  );
}
