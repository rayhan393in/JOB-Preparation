import { useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  CalendarDays,
  Check,
  Clock3,
  Edit3,
  Plus,
  Sparkles,
  Trash2,
} from "lucide-react";
import {
  api,
  useApp,
  Heading,
  Button,
  LinkButton,
  Field,
  Select,
  Empty,
  Status,
  useLoad,
  Modal,
  dateKey,
  scoreClass,
  qstr,
} from "./ui";
import { Filters } from "./questions";
export function Routine() {
  const { routine, syllabus, track, ensure, refresh, toast } = useApp();
  const [d, D] = useState(dateKey()),
    [edit, U] = useState<any>(null),
    [error, E] = useState(""),
    [busy, B] = useState(false);
  const current = routine.filter((x) => x.day === d);
  const mutate = async (path: string, method: string, body?: any) => {
    B(true);
    E("");
    try {
      await ensure();
      await api(path, method, body);
      await refresh();
      return true;
    } catch (e) {
      E(e.message);
      return false;
    } finally {
      B(false);
    }
  };
  const move = async (i: number, n: number) => {
    const a = current[i],
      b = current[n];
    if (!b) return;
    await mutate("/routine", "POST", { ...a, position: b.position });
    await mutate("/routine", "POST", { ...b, position: a.position });
  };
  return (
    <>
      <Heading
        title="Daily Study Routine"
        eyebrow="STUDY PLANNER"
        subtitle="Generate a focused study plan or build your own schedule."
        action={
          <LinkButton to="settings" variant="subtle">
            Routine preferences
          </LinkButton>
        }
      />
      <section className="panel block">
        <div className="toolbar">
          <Field label="Study date">
            <input type="date" value={d} onChange={(e) => D(e.target.value)} />
          </Field>
          <div className="row">
            <Button
              variant="subtle"
              onClick={() => {
                E("");
                U({
                  day: d,
                  subject: "",
                  topic: "",
                  subtopic: "",
                  minutes: 45,
                  position: Math.max(-1, ...current.map((x) => x.position)) + 1,
                });
              }}
            >
              <Plus size={16} /> Add session
            </Button>
            <Button
              variant="primary"
              disabled={busy || !d}
              onClick={async () => {
                const manual = current.some((x) => x.manual);
                if (
                  manual &&
                  !confirm(
                    "Replace your manually edited sessions for this date?",
                  )
                )
                  return;
                if (
                  await mutate("/routine/generate", "POST", {
                    day: d,
                    track,
                    confirm: manual,
                  })
                )
                  toast("Study plan generated.");
              }}
            >
              <Sparkles size={17} /> Generate routine
            </Button>
          </div>
        </div>
        <Status error={!edit ? error : ""} />
        <div className="section-bar">
          <div className="section-title">Scheduled sessions</div>
          <span className="muted">
            {current.filter((x) => x.completed).length} / {current.length}{" "}
            completed · {current.reduce((a, x) => a + x.minutes, 0)} min
          </span>
        </div>
        {current.length ? (
          <div className="study-list">
            {current.map((x, i) => (
              <div className="study-row routine-row" key={x.id}>
                <button
                  className={
                    "icon-btn check-btn " + (x.completed ? "complete" : "")
                  }
                  aria-label={x.completed ? "Mark incomplete" : "Mark complete"}
                  onClick={() =>
                    mutate("/routine", "POST", {
                      ...x,
                      completed: !x.completed,
                    })
                  }
                >
                  {x.completed && <Check size={17} />}
                </button>
                <div>
                  <strong>{x.subtopic}</strong>
                  <small>
                    {syllabus.find((s) => s.id === x.subject)?.name} ·{" "}
                    {x.minutes} min
                  </small>
                </div>
                <div className="row compact">
                  <button
                    className="icon-btn"
                    aria-label="Move up"
                    disabled={i === 0 || busy}
                    onClick={() => move(i, i - 1)}
                  >
                    <ArrowUp size={15} />
                  </button>
                  <button
                    className="icon-btn"
                    aria-label="Move down"
                    disabled={i === current.length - 1 || busy}
                    onClick={() => move(i, i + 1)}
                  >
                    <ArrowDown size={15} />
                  </button>
                  <button
                    className="icon-btn"
                    aria-label="Edit or postpone session"
                    onClick={() => {
                      E("");
                      U(x);
                    }}
                  >
                    <Edit3 size={15} />
                  </button>
                  <button
                    className="icon-btn danger"
                    aria-label="Delete session"
                    onClick={() => {
                      if (confirm("Remove this session?"))
                        mutate("/routine/" + x.id, "DELETE");
                    }}
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Empty
            title="No sessions for this date"
            description="Generate a routine or add a session yourself."
          />
        )}
      </section>
      {edit && (
        <Modal
          title={edit.id ? "Edit study session" : "Add study session"}
          onClose={() => U(null)}
        >
          <form
            className="stack"
            onSubmit={async (e) => {
              e.preventDefault();
              if (await mutate("/routine", "POST", edit)) {
                U(null);
                toast("Study session saved.");
              }
            }}
          >
            <div className="filters bare">
              <Filters v={edit} on={(x) => U({ ...edit, ...x })} />
              <Field label="Duration (minutes)">
                <input
                  type="number"
                  min="5"
                  max="360"
                  required
                  value={edit.minutes}
                  onChange={(e) => U({ ...edit, minutes: e.target.value })}
                />
              </Field>
              <Field label="Date (change to postpone)">
                <input
                  type="date"
                  required
                  value={edit.day}
                  onChange={(e) => U({ ...edit, day: e.target.value })}
                />
              </Field>
            </div>
            <Status error={error} />
            <Button variant="primary" type="submit" disabled={busy}>
              Save session
            </Button>
          </form>
        </Modal>
      )}
    </>
  );
}
export function History() {
  const { track, syllabus } = useApp();
  const source = useLoad<any[]>("/history", []);
  const [v, V] = useState<any>({ track }),
    [page, P] = useState(1);
  const list = source.data
    .filter(
      (x) =>
        (v.track === "Both" || v.track === x.track) &&
        (!v.subject || x.subject === v.subject) &&
        (!v.topic || x.topic === v.topic) &&
        (!v.subtopic || x.subtopic === v.subtopic),
    )
    .sort((a, b) => (b.score ?? -1) - (a.score ?? -1));
  function exportData() {
    const blob = new Blob([JSON.stringify(list, null, 2)], {
        type: "application/json",
      }),
      url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "historical-topic-analysis.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }
  return (
    <>
      <Heading
        title="Historical Topic Analysis"
        eyebrow="INSIGHTS"
        subtitle="Compare verified paper appearances with your own topic performance."
        action={
          <Button variant="subtle" onClick={exportData} disabled={!list.length}>
            Export JSON
          </Button>
        }
      />
      <div className="notice">
        <strong>
          {source.data.some((x) => x.frequency !== null)
            ? "Verified-paper statistics"
            : "No verified historical frequency yet"}
        </strong>
        <p>
          Frequency and repeats only use administrator-verified paper questions.
          Missing inputs are excluded from the estimate; priority labels are not
          historical counts.
        </p>
        <LinkButton to="settings">Adjust priority weights</LinkButton>
      </div>
      <div className="panel filters">
        <Filters
          v={v}
          on={(x) => {
            V({ ...v, ...x });
            P(1);
          }}
        />
      </div>
      <Status {...source} />
      <section className="panel block">
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Subtopic</th>
                <th>Frequency</th>
                <th>Share</th>
                <th>Appeared in</th>
                <th>Repeats</th>
                <th>Last year</th>
                <th>Accuracy</th>
                <th>Priority</th>
              </tr>
            </thead>
            <tbody>
              {list.slice((page - 1) * 14, page * 14).map((x) => (
                <tr key={x.subject + "|" + x.topic + "|" + x.subtopic}>
                  <td>
                    <strong>{x.subtopic}</strong>
                    <small className="muted cell-caption">
                      {syllabus.find((s) => s.id === x.subject)?.name}
                    </small>
                  </td>
                  <td>{x.frequency ?? "—"}</td>
                  <td>{x.percentage === null ? "—" : x.percentage + "%"}</td>
                  <td>{x.appeared.join(", ") || "—"}</td>
                  <td>{x.frequency === null ? "—" : x.repeated}</td>
                  <td>{x.last ?? "—"}</td>
                  <td>
                    {x.accuracy === null ? "—" : Math.round(x.accuracy) + "%"}
                  </td>
                  <td>
                    <span className="tag lavender">{scoreClass(x.score)}</span>
                    {x.score !== null && (
                      <small className="muted cell-caption">
                        {x.score}/100{x.estimated ? " · Estimate" : ""}
                      </small>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="pager">
          <Button
            variant="subtle"
            disabled={page <= 1}
            onClick={() => P(page - 1)}
          >
            Previous
          </Button>
          <span>
            {page} / {Math.max(1, Math.ceil(list.length / 14))}
          </span>
          <Button
            variant="subtle"
            disabled={page * 14 >= list.length}
            onClick={() => P(page + 1)}
          >
            Next
          </Button>
        </div>
      </section>
    </>
  );
}
export function Revision({ weak = false }: { weak?: boolean }) {
  const { track, exams, syllabus, user, settings } = useApp();
  const source = useLoad<any[]>(user ? "/revision" : null, []);
  const [tab, T] = useState("Due today"),
    [open, O] = useState("");
  const selected = source.data.filter(
    (x) =>
      track === "Both" ||
      syllabus.find((s) => s.id === x.subject)?.track === track,
  );
  const topics = Object.entries(
    exams
      .flatMap((e) => e.topics || [])
      .filter(
        (x) =>
          (track === "Both" || x.track === track) && x.outcome !== "Unanswered",
      )
      .reduce(
        (m, x) => {
          const k = x.subject + "|" + x.subtopic;
          m[k] ??= [0, 0];
          m[k][0]++;
          m[k][1] += +(x.outcome === "Correct");
          return m;
        },
        {} as Record<string, number[]>,
      ) as Record<string, number[]>,
  )
    .map(([k, [n, c]]) => ({ k, n, p: Math.round((100 * c) / n) }))
    .sort((a, b) => a.p - b.p)
    .slice(0, 5);
  const [strong, good, moderate] = settings.thresholds || [85, 70, 50];
  const list = selected.filter((x) =>
    tab === "Due today" ? x.due <= dateKey() : true,
  );
  return (
    <>
      <Heading
        title={weak ? "Weakness Recovery" : "Revision Center"}
        eyebrow="REVIEW"
        subtitle={
          weak
            ? "See which topics need more practice and retry missed questions."
            : "Revisit missed questions on a 1, 3, 7, 15 and 30 day schedule."
        }
        action={
          <LinkButton
            to={
              "manual?selection=" +
              encodeURIComponent(weak ? "Incorrect" : "Revision due")
            }
            variant="primary"
          >
            Build a review exam
          </LinkButton>
        }
      />
      {weak && (
        <section className="panel block">
          <h2>Five lowest-accuracy topics</h2>
          {topics.length ? (
            <div className="study-list">
              {topics.map((x) => {
                const [id, label] = x.k.split("|"),
                  s = syllabus.find((s) => s.id === id);
                return (
                  <div className="study-row" key={x.k}>
                    <div>
                      <strong>{label}</strong>
                      <small>
                        {s?.name} · {x.n} answered
                      </small>
                    </div>
                    <span className="tag lavender">
                      {x.p}% ·{" "}
                      {x.p >= strong
                        ? "Strong"
                        : x.p >= good
                          ? "Good"
                          : x.p >= moderate
                            ? "Moderate"
                            : "Weak"}
                    </span>
                    <LinkButton
                      to={
                        "manual?" +
                        qstr({ track: s?.track, subject: id, subtopic: label })
                      }
                    >
                      Practice
                    </LinkButton>
                  </div>
                );
              })}
            </div>
          ) : (
            <Empty
              title="Not enough exam activity"
              description="Finish a practice exam to get topic recommendations."
            />
          )}
        </section>
      )}
      <section className="panel block">
        <div className="toolbar">
          <h2>{weak ? "Incorrect question notebook" : "Revision schedule"}</h2>
          {!weak && (
            <div className="segmented">
              {["Due today", "Calendar"].map((x) => (
                <button
                  key={x}
                  className={tab === x ? "active" : ""}
                  onClick={() => T(x)}
                >
                  {x}
                </button>
              ))}
            </div>
          )}
        </div>
        <Status {...source} />
        {(weak ? selected : list).length ? (
          <div className="stack inset">
            {(weak ? selected : list).map((x) => (
              <article className="revision-row" key={x.question_id}>
                <div className="toolbar">
                  <div>
                    <small className="muted">
                      {x.subtopic} · Due {x.due}
                    </small>
                    <h3>{x.text}</h3>
                  </div>
                  <Button
                    variant="subtle"
                    onClick={() =>
                      O(open === x.question_id ? "" : x.question_id)
                    }
                  >
                    {open === x.question_id ? "Hide" : "Review"}
                  </Button>
                </div>
                {open === x.question_id && (
                  <div className="explanation">
                    <strong>{x.options[x.answer]}</strong>
                    <p>{x.explanation}</p>
                  </div>
                )}
              </article>
            ))}
          </div>
        ) : (
          <Empty
            title={
              weak
                ? "Nothing to recover yet"
                : tab === "Due today"
                  ? "No reviews due today"
                  : "No revision sessions scheduled"
            }
            description="Incorrect answers will appear here after an examination."
          />
        )}
      </section>
    </>
  );
}
export function Notes() {
  const { user, ensure, toast } = useApp();
  const source = useLoad<any[]>(user ? "/notes" : null, []);
  const [edit, U] = useState<any>(null),
    [error, E] = useState(""),
    [busy, B] = useState(false);
  return (
    <>
      <Heading
        title="My Notes"
        eyebrow="MY LIBRARY"
        subtitle="Keep your formulas, reminders and study summaries together."
        action={
          <Button
            variant="primary"
            onClick={() => {
              U({ title: "", body: "" });
              E("");
            }}
          >
            <Plus size={16} /> New note
          </Button>
        }
      />
      <Status {...source} />
      {source.data.length ? (
        <div className="track-grid">
          {source.data.map((n) => (
            <article key={n.id} className="panel block note">
              <h2>{n.title}</h2>
              <p>{n.body}</p>
              <div className="row">
                <Button
                  variant="subtle"
                  onClick={() => {
                    U(n);
                    E("");
                  }}
                >
                  <Edit3 size={14} /> Edit
                </Button>
                <Button
                  variant="text danger"
                  onClick={async () => {
                    if (confirm("Delete this note?"))
                      try {
                        await api("/notes/" + n.id, "DELETE");
                        source.reload();
                        toast("Note deleted.");
                      } catch (e) {
                        toast(e.message);
                      }
                  }}
                >
                  <Trash2 size={14} /> Delete
                </Button>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <section className="panel">
          <Empty
            title="No notes yet"
            description="Create a note to capture something worth revisiting."
          />
        </section>
      )}
      {edit && (
        <Modal
          title={edit.id ? "Edit note" : "New note"}
          onClose={() => U(null)}
        >
          <form
            className="stack"
            onSubmit={async (e) => {
              e.preventDefault();
              B(true);
              E("");
              try {
                await ensure();
                await api("/notes", "POST", edit);
                U(null);
                source.reload();
                toast("Note saved.");
              } catch (e) {
                E(e.message);
              } finally {
                B(false);
              }
            }}
          >
            <Field label="Title">
              <input
                autoFocus
                required
                value={edit.title}
                onChange={(e) => U({ ...edit, title: e.target.value })}
              />
            </Field>
            <Field label="Note">
              <textarea
                rows={7}
                required
                value={edit.body}
                onChange={(e) => U({ ...edit, body: e.target.value })}
              />
            </Field>
            <Status error={error} />
            <Button type="submit" variant="primary" disabled={busy}>
              Save note
            </Button>
          </form>
        </Modal>
      )}
    </>
  );
}
export function Settings({ dark, setDark, language, setLanguage }: any) {
  const { user, settings, track, ensure, refresh, auth, toast } = useApp();
  const [v, V] = useState<any>({
    minutes: 90,
    subjects: 2,
    restDays: [],
    target: "",
    thresholds: [85, 70, 50],
    weights: [35, 25, 20, 20],
    ...settings,
    track,
  });
  const [error, E] = useState(""),
    [busy, B] = useState(false);
  return (
    <>
      <Heading
        title="Settings"
        eyebrow="YOUR WORKSPACE"
        subtitle="Personalize your study schedule, priority weights and display."
      />
      <div className="split">
        <form
          className="panel block stack"
          onSubmit={async (e) => {
            e.preventDefault();
            B(true);
            E("");
            try {
              await ensure();
              await api("/settings", "PUT", v);
              await refresh();
              toast("Preferences saved.");
            } catch (e) {
              E(e.message);
            } finally {
              B(false);
            }
          }}
        >
          <h2>Preparation preferences</h2>
          <div className="filters bare">
            <Select
              label="Default track"
              value={v.track}
              opts={["Both", "BCS", "EEE"]}
              onChange={(x) => V({ ...v, track: x })}
            />
            <Field label="Study minutes per day">
              <input
                type="number"
                min="10"
                max="720"
                value={v.minutes}
                onChange={(e) => V({ ...v, minutes: +e.target.value })}
              />
            </Field>
            <Field label="Subjects per day">
              <input
                type="number"
                min="2"
                max="8"
                value={v.subjects}
                onChange={(e) => V({ ...v, subjects: +e.target.value })}
              />
            </Field>
            <Field label="Target exam date">
              <input
                type="date"
                value={v.target}
                onChange={(e) => V({ ...v, target: e.target.value })}
              />
            </Field>
          </div>
          <div className="row compact">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((x, i) => (
              <label className="check-label" key={x}>
                <input
                  type="checkbox"
                  checked={v.restDays.includes(i)}
                  onChange={(e) =>
                    V({
                      ...v,
                      restDays: e.target.checked
                        ? [...v.restDays, i]
                        : v.restDays.filter((x) => x !== i),
                    })
                  }
                />
                {x}
              </label>
            ))}
          </div>
          <small className="muted">Selected days are rest days.</small>
          <hr />
          <h2>Topic priority weights</h2>
          <div className="filters bare">
            {[
              "Historical frequency",
              "Recent frequency",
              "Syllabus importance",
              "Personal weakness",
            ].map((x, i) => (
              <Field label={x + " (%)"} key={x}>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={v.weights[i]}
                  onChange={(e) =>
                    V({
                      ...v,
                      weights: v.weights.map((z, j) =>
                        j === i ? +e.target.value : z,
                      ),
                    })
                  }
                />
              </Field>
            ))}
          </div>
          <span className="muted">
            Total: {v.weights.reduce((a, b) => a + b, 0)} / 100
          </span>
          <h2>Accuracy thresholds</h2>
          <div className="filters bare">
            {["Strong", "Good", "Moderate"].map((x, i) => (
              <Field label={x + " (%)"} key={x}>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={v.thresholds[i]}
                  onChange={(e) =>
                    V({
                      ...v,
                      thresholds: v.thresholds.map((z, j) =>
                        j === i ? +e.target.value : z,
                      ),
                    })
                  }
                />
              </Field>
            ))}
          </div>
          <Status error={error} />
          <Button type="submit" variant="primary" disabled={busy}>
            Save preferences
          </Button>
        </form>
        <div className="stack">
          <div className="panel block stack">
            <h2>Appearance</h2>
            <Select
              label="Theme"
              value={dark ? "Dark" : "Light"}
              opts={["Light", "Dark"]}
              onChange={(x) => setDark(x === "Dark")}
            />
            <Select
              label="Dashboard & syllabus language"
              value={language}
              opts={[
                { label: "English", value: "en" },
                { label: "বাংলা", value: "bn" },
              ]}
              onChange={setLanguage}
            />
          </div>
          <div className="panel block stack">
            <h2>Account</h2>
            <p className="muted">
              {user?.email ||
                "Sign in to keep your progress available across devices. Guest progress belongs to this browser session."}
            </p>
            {(!user || user.role === "guest") && (
              <Button variant="primary" onClick={auth}>
                Sign in or create an account
              </Button>
            )}
            {user?.role === "admin" && (
              <LinkButton to="admin">Content workspace</LinkButton>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
