import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Check,
  ChevronRight,
  ClipboardList,
  Clock3,
  Flag,
  Play,
  Timer,
  Target,
  Zap,
} from "lucide-react";
import {
  api,
  useApp,
  Heading,
  Button,
  LinkButton,
  Field,
  Select,
  Empty,
  Status,
  useLoad,
  Modal,
} from "./ui";
import { Filters } from "./questions";
export function ExamBuilder({
  mode,
  params,
}: {
  mode: string;
  params: URLSearchParams;
}) {
  const { track, ensure, go, exams, syllabus } = useApp();
  const start = params.get("track") || (track === "EEE" ? "EEE" : "BCS");
  const defaults = (t: string) => ({
    count: mode === "mock" ? (t === "BCS" ? 200 : 60) : t === "EEE" ? 30 : 25,
    duration:
      mode === "mock" ? (t === "BCS" ? 120 : 60) : t === "EEE" ? 20 : 15,
    penalty: t === "BCS" ? 0.5 : 0,
  });
  const [v, V] = useState<any>({
    track: start,
    ...defaults(start),
    selection: params.get("selection") || "All",
    subject: params.get("subject") || "",
    subtopic: params.get("subtopic") || "",
    subjects: [],
    distribution: [40, 25, 15, 10, 10],
  });
  const [busy, B] = useState(false),
    [error, E] = useState("");
  const titles = {
    daily: "Daily MCQ Examination",
    manual: "Manual Examination",
    mock: "Mock Examination",
  };
  const active = exams.find(
    (a) =>
      !a.submitted_at &&
      a.mode === mode &&
      a.track === v.track &&
      new Date(a.ends_at) > new Date(),
  );
  const set = (x: any) =>
    V((s: any) => ({
      ...s,
      ...(x.track && x.track !== s.track
        ? { ...defaults(x.track), subjects: [] }
        : {}),
      ...x,
      ...(x.subject ? { subjects: [] } : {}),
      ...(x.subjects?.length ? { subject: "", topic: "", subtopic: "" } : {}),
    }));
  const fixed = mode === "mock" && v.track === "BCS";
  return (
    <>
      <Heading
        title={titles[mode]}
        eyebrow="EXAM CENTER"
        subtitle={
          mode === "daily"
            ? "A timed practice session that prioritizes today’s study topics and due revisions."
            : mode === "manual"
              ? "Choose what to practice and build a timed exam from matching questions."
              : "Simulate exam conditions with a longer, timed practice test."
        }
      />
      <div className="split">
        <form
          className="panel block stack"
          onSubmit={async (e) => {
            e.preventDefault();
            B(true);
            E("");
            try {
              await ensure();
              const a = await api("/exams", "POST", { ...v, mode });
              go("exam/" + a.id);
            } catch (e) {
              E(e.message);
            } finally {
              B(false);
            }
          }}
        >
          <div className="panel-head">
            <div>
              <h2>Exam configuration</h2>
              <p>Choose your track and settings before you begin.</p>
            </div>
            <span className="icon-tile lavender">
              <ClipboardList size={20} />
            </span>
          </div>
          {mode === "manual" ? (
            <div className="filters bare">
              <Filters v={v} on={set} organization />
              <Select
                label="Difficulty"
                value={v.difficulty || ""}
                placeholder="All levels"
                opts={["Easy", "Medium", "Hard"]}
                onChange={(x) => set({ difficulty: x })}
              />
              <Select
                label="Question source"
                value={v.selection}
                opts={[
                  "All",
                  "Original practice",
                  "Verified past questions",
                  "Unattempted",
                  "Incorrect",
                  "Bookmarked",
                  "Revision due",
                ]}
                onChange={(x) => set({ selection: x })}
              />
            </div>
          ) : (
            <Select
              label="Preparation track"
              value={v.track}
              opts={mode === "mock" ? ["BCS", "EEE"] : ["BCS", "EEE", "Both"]}
              onChange={(x) => set({ track: x })}
            />
          )}
          <div className="filters bare">
            <Field label="Questions">
              <input
                type="number"
                min={mode === "daily" ? 2 : 1}
                max={200}
                required
                disabled={fixed}
                value={v.count}
                onChange={(e) => set({ count: e.target.value })}
              />
            </Field>
            <Field label="Duration (minutes)">
              <input
                type="number"
                min="1"
                max="240"
                required
                disabled={fixed}
                value={v.duration}
                onChange={(e) => set({ duration: e.target.value })}
              />
            </Field>
            <Field label="Incorrect answer penalty">
              <input
                type="number"
                min="0"
                max="1"
                step="0.01"
                required
                value={v.penalty}
                onChange={(e) => set({ penalty: e.target.value })}
              />
            </Field>
          </div>
          {(mode === "manual" || (mode === "mock" && !fixed)) && (
            <details className="settings-extra">
              <summary>
                Select multiple subjects <ChevronRight size={15} />
              </summary>
              <div className="filters bare">
                {syllabus
                  .filter((s) => v.track === "Both" || s.track === v.track)
                  .map((s) => (
                    <label className="check-label" key={s.id}>
                      <input
                        type="checkbox"
                        checked={v.subjects.includes(s.id)}
                        onChange={(e) =>
                          set({
                            subjects: e.target.checked
                              ? [...v.subjects, s.id]
                              : v.subjects.filter((x) => x !== s.id),
                          })
                        }
                      />
                      {s.name}
                    </label>
                  ))}
              </div>
            </details>
          )}
          {mode === "daily" && (
            <details className="settings-extra">
              <summary>
                Customize question mix <ChevronRight size={15} />
              </summary>
              <p className="muted">
                Missing categories are filled from available questions. At least
                two subjects are always included.
              </p>
              <div className="filters bare">
                {[
                  "High priority",
                  "Medium priority",
                  "Revision",
                  "Weak topics",
                  "Previous-year",
                ].map((x, i) => (
                  <Field label={x + " (%)"} key={x}>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={v.distribution[i]}
                      onChange={(e) =>
                        set({
                          distribution: v.distribution.map((z, j) =>
                            j === i ? +e.target.value : z,
                          ),
                        })
                      }
                    />
                  </Field>
                ))}
              </div>
            </details>
          )}
          <Status error={error} />
          <div className="row">
            <Button type="submit" variant="primary" disabled={busy}>
              <Play size={16} />{" "}
              {busy ? "Preparing exam…" : "Start examination"}
            </Button>
            {active && (
              <LinkButton to={"exam/" + active.id}>
                Resume active attempt
              </LinkButton>
            )}
          </div>
        </form>
        <aside className="panel block instructions">
          <span className="icon-tile gold">
            <Timer size={21} />
          </span>
          <h2>Before you begin</h2>
          <ul>
            <li>The timer starts as soon as you open the exam.</li>
            <li>Your answers and review flags are saved while you work.</li>
            <li>
              Each correct answer earns 1 mark. Unanswered questions have no
              penalty.
            </li>
            <li>Review explanations after you submit.</li>
            {mode === "daily" && (
              <li>Daily exams include at least two subjects.</li>
            )}
            {fixed && (
              <li>
                The BCS full mock requires enough questions in every subject to
                match the 200-mark distribution.
              </li>
            )}
          </ul>
        </aside>
      </div>
    </>
  );
}
export function ExamRoom({ id }: { id: string }) {
  const { refresh, syllabus, toast } = useApp();
  const source = useLoad<any>("/exams/" + id, null);
  const [a, A] = useState<any>(null),
    [pos, P] = useState(0),
    [clock, C] = useState(Date.now()),
    [confirm, S] = useState(false),
    [busy, B] = useState(false),
    [error, E] = useState("");
  const queue = useRef(Promise.resolve()),
    guard = useRef(false),
    entered = useRef(Date.now()),
    last = useRef({} as any);
  useEffect(() => {
    if (source.data) {
      A(source.data);
      last.current = source.data.answers;
      entered.current = Date.now();
    }
  }, [source.data]);
  useEffect(() => {
    const timer = setInterval(() => C(Date.now()), 350);
    return () => clearInterval(timer);
  }, []);
  const left = a
    ? Math.max(0, Math.ceil((+new Date(a.ends_at) - clock) / 1000))
    : 0;
  function save(position: number, change: any = {}) {
    const before = last.current[position] || {
      choice: null,
      review: false,
      seconds: 0,
    };
    const updated = {
      ...before,
      ...change,
      seconds:
        before.seconds +
        Math.max(0, Math.floor((Date.now() - entered.current) / 1000)),
    };
    entered.current = Date.now();
    last.current = { ...last.current, [position]: updated };
    A((x) => ({ ...x, answers: last.current }));
    queue.current = queue.current
      .then(() => api(`/exams/${id}/answer`, "PUT", { position, ...updated }))
      .then(() => {})
      .catch((e) => {
        E(
          e.message === "The examination is closed."
            ? ""
            : `Answer not saved: ${e.message}`,
        );
      });
  }
  async function submit(expiry = false) {
    if (guard.current) return;
    guard.current = true;
    B(true);
    E("");
    try {
      if (!expiry) save(pos);
      await queue.current;
      const result = await api(`/exams/${id}/submit`, "POST", {});
      A(result);
      S(false);
      await refresh();
      window.scrollTo(0, 0);
    } catch (e) {
      E(e.message);
    } finally {
      B(false);
      guard.current = false;
    }
  }
  useEffect(() => {
    if (a && !a.submitted_at && left === 0) submit(true);
  }, [!!a, left, a?.submitted_at]);
  if (!a) return <Status {...source} />;
  if (a.result) {
    const r = a.result,
      groups = Object.entries(
        r.rows.reduce(
          (m, x) => {
            const k = x.subject + "|" + x.subtopic;
            m[k] ??= [0, 0, 0];
            m[k][0] += +(x.outcome === "Correct");
            m[k][1] += +(x.outcome === "Incorrect");
            m[k][2]++;
            return m;
          },
          {} as Record<string, number[]>,
        ) as Record<string, number[]>,
      );
    return (
      <>
        <Heading
          title="Examination Results"
          eyebrow={`${a.track} · ${a.mode.toUpperCase()}`}
          subtitle={`Time spent: ${Math.max(0, Math.round((+new Date(a.submitted_at) - +new Date(a.started_at)) / 1000))} seconds`}
          action={
            <LinkButton to="analytics" variant="primary">
              View analytics
            </LinkButton>
          }
        />
        <div className="metric-grid results-metrics">
          {[
            ["Score", `${r.score} / ${r.rows.length}`],
            ["Accuracy", r.accuracy + "%"],
            ["Correct / Incorrect", `${r.correct} / ${r.incorrect}`],
            ["Unanswered", r.unanswered],
          ].map(([label, val]) => (
            <div className="panel metric" key={label}>
              <p>{label}</p>
              <strong>{val}</strong>
            </div>
          ))}
        </div>
        <section className="panel block">
          <h2>Subject and topic breakdown</h2>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Subject</th>
                  <th>Subtopic</th>
                  <th>Correct</th>
                  <th>Incorrect</th>
                  <th>Score</th>
                </tr>
              </thead>
              <tbody>
                {groups.map(([k, [c, i, n]]) => (
                  <tr key={k}>
                    <td>
                      {syllabus.find((s) => s.id === k.split("|")[0])?.name}
                    </td>
                    <td>{k.split("|")[1]}</td>
                    <td>
                      {c}/{n}
                    </td>
                    <td>{i}</td>
                    <td>{+(c - i * Number(a.penalty)).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
        <div className="section-bar">
          <div className="section-title">Answer review</div>
        </div>
        <div className="stack">
          {r.rows.map((q, i) => (
            <article className="panel question-card" key={q.id}>
              <span
                className={
                  "tag " +
                  (q.outcome === "Correct"
                    ? "green"
                    : q.outcome === "Incorrect"
                      ? "peach"
                      : "")
                }
              >
                {q.outcome}
              </span>
              <h3>
                {i + 1}. {q.text}
              </h3>
              <p className="muted">
                Your answer:{" "}
                {q.choice === null ? "Unanswered" : q.options[q.choice]} ·{" "}
                {q.seconds}s on this question
              </p>
              <div className="explanation">
                <strong>Correct answer: {q.options[q.answer]}</strong>
                <p>{q.explanation}</p>
              </div>
            </article>
          ))}
        </div>
      </>
    );
  }
  const q = a.questions[pos],
    answer = a.answers[pos] || {},
    answered = Object.values(a.answers).filter(
      (x: any) => x.choice != null,
    ).length;
  function move(next: number) {
    if (next === pos) return;
    save(pos);
    P(next);
    entered.current = Date.now();
  }
  return (
    <>
      <Heading
        title="Examination in progress"
        eyebrow={`${a.track} · ${a.mode.toUpperCase()}`}
        subtitle={`${answered} of ${a.questions.length} questions answered`}
        action={
          <div className={"date-chip timer " + (left < 60 ? "danger" : "")}>
            <Clock3 size={18} />
            {String(Math.floor(left / 60)).padStart(2, "0")}:
            {String(left % 60).padStart(2, "0")}
          </div>
        }
      />
      <Status error={error} />
      <div className="split exam-split">
        <section className="panel block stack">
          <div className="tagline">
            <span className="tag lavender">
              Question {pos + 1} of {a.questions.length}
            </span>
            <span className="tag">
              {syllabus.find((s) => s.id === q.subject)?.name}
            </span>
            <span className="tag">{q.subtopic}</span>
          </div>
          <h2>{q.text}</h2>
          <div className="exam-options">
            {q.options.map((x, i) => (
              <button
                type="button"
                key={i}
                className={answer.choice === i ? "chosen" : ""}
                disabled={busy || left === 0}
                onClick={() => save(pos, { choice: i })}
              >
                <b>{"ABCD"[i]}</b>
                {x}
                {answer.choice === i && <Check size={18} />}
              </button>
            ))}
          </div>
          <div className="toolbar">
            <div className="row">
              <Button
                variant="subtle"
                disabled={busy || answer.choice == null}
                onClick={() => save(pos, { choice: null })}
              >
                Clear answer
              </Button>
              <Button
                variant={answer.review ? "gold-button" : "subtle"}
                disabled={busy}
                onClick={() => save(pos, { review: !answer.review })}
              >
                <Flag size={15} />{" "}
                {answer.review ? "Marked for review" : "Mark for review"}
              </Button>
            </div>
            <div className="row">
              <Button
                variant="subtle"
                disabled={pos === 0 || busy}
                onClick={() => move(pos - 1)}
              >
                <ArrowLeft size={16} /> Previous
              </Button>
              <Button
                variant="primary"
                disabled={pos === a.questions.length - 1 || busy}
                onClick={() => move(pos + 1)}
              >
                Next <ArrowRight size={16} />
              </Button>
            </div>
          </div>
        </section>
        <aside className="panel block stack">
          <h2>Question navigator</h2>
          <div className="exam-nav">
            {a.questions.map((q, i) => (
              <button
                key={q.id}
                className={`${i === pos ? "here" : ""} ${a.answers[i]?.choice != null ? "answered" : ""} ${a.answers[i]?.review ? "flagged" : ""}`}
                aria-label={`Question ${i + 1}`}
                onClick={() => move(i)}
              >
                {i + 1}
              </button>
            ))}
          </div>
          <div className="tagline">
            <span className="tag green">Answered</span>
            <span className="tag gold">Review</span>
            <span className="tag">Not answered</span>
          </div>
          <Button variant="primary" disabled={busy} onClick={() => S(true)}>
            {busy ? "Submitting…" : "Submit examination"}
          </Button>
        </aside>
      </div>
      {confirm && (
        <Modal title="Submit examination?" onClose={() => !busy && S(false)}>
          <p className="muted">
            You have {a.questions.length - answered} unanswered questions.
            Answers cannot be changed after submission.
          </p>
          <div className="row modal-actions">
            <Button variant="subtle" disabled={busy} onClick={() => S(false)}>
              Keep working
            </Button>
            <Button variant="primary" disabled={busy} onClick={() => submit()}>
              Submit examination
            </Button>
          </div>
        </Modal>
      )}
    </>
  );
}
