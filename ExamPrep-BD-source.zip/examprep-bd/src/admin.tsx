import { useEffect, useState } from "react";
import { Download, Upload, ShieldCheck, Plus } from "lucide-react";
import {
  api,
  useApp,
  Heading,
  Button,
  LinkButton,
  Field,
  Select,
  Empty,
  Status,
  useLoad,
  Modal,
} from "./ui";
const template =
  "subject,topic,subtopic,text,a,b,c,d,answer,explanation,difficulty,kind,source,paper_id,tags\nmath,Arithmetic,Percentage,What is 10% of 50?,2,5,10,20,B,50 multiplied by 0.10 is 5,Easy,Original practice,Example template,,percentage\n";
const fresh = () => ({
  id: "",
  track: "BCS",
  subject: "",
  topic: "",
  subtopic: "",
  text: "",
  options: ["", "", "", ""],
  answer: 0,
  explanation: "",
  difficulty: "Easy",
  kind: "Original practice",
  source: "",
  paper_id: "",
});
export function Admin({ params }: { params: URLSearchParams }) {
  const { user, syllabus, orgs, refresh, toast, go } = useApp();
  const id = params.get("edit"),
    allowed = user?.role === "admin";
  const papers = useLoad<any[]>(allowed ? "/papers?admin=1" : null, []),
    reports = useLoad<any[]>(allowed ? "/admin/reports" : null, []),
    question = useLoad<any>(
      allowed && id ? "/admin/questions/" + id : null,
      null,
    ),
    history = useLoad<any[]>(
      allowed && id ? "/admin/questions/" + id + "/history" : null,
      [],
    );
  const [q, Q] = useState<any>(fresh()),
    [p, P] = useState<any>({
      id: "",
      name: "",
      track: "BCS",
      year: 2026,
      source: "",
      organization: "",
    }),
    [form, F] = useState(id ? "question" : ""),
    [file, L] = useState<File | null>(null),
    [preview, V] = useState<any>(null),
    [error, E] = useState(""),
    [busy, B] = useState(false),
    [marks, M] = useState<any>({});
  useEffect(() => {
    if (id) F("question");
  }, [id]);
  useEffect(() => {
    if (question.data) Q(question.data);
  }, [question.data]);
  useEffect(
    () =>
      M(
        Object.fromEntries(
          syllabus.filter((x) => x.track === "BCS").map((x) => [x.id, x.marks]),
        ),
      ),
    [syllabus],
  );
  const action = async (f: () => Promise<any>) => {
    B(true);
    E("");
    try {
      await f();
      return true;
    } catch (e) {
      E(e.message);
      return false;
    } finally {
      B(false);
    }
  };
  const s = syllabus.find((s) => s.id === q.subject);
  function close() {
    F("");
    Q(fresh());
    E("");
    if (id) go("admin");
  }
  async function payload() {
    if (!file) throw Error("Choose a file first.");
    const format = file.name.split(".").pop()?.toLowerCase();
    if (!["csv", "xlsx", "json"].includes(format || ""))
      throw Error("Use CSV, XLSX or JSON.");
    if (file.size > 7_000_000) throw Error("Choose a file under 7 MB.");
    const content =
      format === "xlsx"
        ? await new Promise<string>((resolve, reject) => {
            const r = new FileReader();
            r.onload = () => resolve(String(r.result).split(",")[1]);
            r.onerror = reject;
            r.readAsDataURL(file);
          })
        : await file.text();
    return { format, content };
  }
  if (!allowed)
    return (
      <>
        <Heading title="Content workspace" />
        <div className="panel">
          <Empty title="Administrator access required" />
        </div>
      </>
    );
  return (
    <>
      <Heading
        title="Content workspace"
        eyebrow="ADMINISTRATION"
        subtitle="Manage practice questions, validate imports and verify past papers."
        action={
          <LinkButton to="manage" variant="primary">
            Manage questions
          </LinkButton>
        }
      />
      <div className="split">
        <div className="stack">
          <section className="panel block stack">
            <h2>Import questions</h2>
            <p className="muted">
              Upload 1–2,500 rows in CSV, XLSX or JSON. Imports are added as
              Pending review. Register historical papers before importing their
              questions.
            </p>
            <a
              className="button subtle"
              href={
                "data:text/csv;charset=utf-8," + encodeURIComponent(template)
              }
              download="examprep-template.csv"
            >
              <Download size={16} /> CSV template
            </a>
            <Field label="Question file">
              <input
                type="file"
                accept=".csv,.json,.xlsx"
                onChange={(e) => {
                  L(e.target.files[0] || null);
                  V(null);
                  E("");
                }}
              />
            </Field>
            <div className="row">
              <Button
                variant="subtle"
                disabled={!file || busy}
                onClick={() =>
                  action(async () =>
                    V(
                      await api("/admin/import", "POST", {
                        ...(await payload()),
                        preview: true,
                      }),
                    ),
                  )
                }
              >
                <Upload size={15} /> Validate file
              </Button>
              <Button
                variant="primary"
                disabled={!preview || busy}
                onClick={() =>
                  action(async () => {
                    const r = await api(
                      "/admin/import",
                      "POST",
                      await payload(),
                    );
                    V(null);
                    L(null);
                    toast(`${r.count} questions imported for review.`);
                  })
                }
              >
                Import validated rows
              </Button>
            </div>
            {preview && (
              <div className="notice">
                <strong>{preview.count} rows passed validation</strong>
                {preview.preview.map((x) => (
                  <p key={x.id}>{x.text}</p>
                ))}
              </div>
            )}
            <Status error={!form ? error : ""} />
          </section>
          <section className="panel block stack">
            <div className="toolbar">
              <h2>Examination papers</h2>
              <Button
                variant="subtle"
                onClick={() => {
                  F("paper");
                  E("");
                }}
              >
                <Plus size={15} /> Register paper
              </Button>
            </div>
            <Status {...papers} />
            {papers.data.length ? (
              papers.data.map((x) => (
                <article className="study-row" key={x.id}>
                  <div>
                    <strong>{x.name}</strong>
                    <small>
                      {x.id} · {x.year} · {x.questions} questions · {x.status}
                    </small>
                  </div>
                  <Button
                    variant="subtle"
                    onClick={() =>
                      action(async () => {
                        await api("/admin/papers/" + x.id, "PUT", {
                          verified: x.status !== "Verified",
                        });
                        papers.reload();
                        await refresh();
                      })
                    }
                  >
                    {x.status === "Verified" ? "Unverify" : "Verify paper"}
                  </Button>
                </article>
              ))
            ) : (
              <Empty title="No papers registered" />
            )}
          </section>
        </div>
        <div className="stack">
          <section className="panel block stack">
            <h2>Question tools</h2>
            <Button
              variant="primary"
              onClick={() => {
                Q(fresh());
                F("question");
                E("");
              }}
            >
              <Plus size={16} /> New question
            </Button>
            <div className="row">
              {["csv", "xlsx", "json"].map((f) => (
                <a
                  key={f}
                  className="button subtle"
                  href={"/api/admin/export/" + f}
                >
                  <Download size={14} /> {f.toUpperCase()}
                </a>
              ))}
            </div>
            <Button
              variant="subtle"
              onClick={() => {
                F("marks");
                E("");
              }}
            >
              Edit BCS marks
            </Button>
          </section>
          <section className="panel block stack">
            <h2>Question reports</h2>
            <Status {...reports} />
            {reports.data.length ? (
              reports.data.map((r) => (
                <article key={r.id}>
                  <strong>{r.text}</strong>
                  <p className="muted">{r.reason}</p>
                </article>
              ))
            ) : (
              <Empty title="No reports submitted" />
            )}
          </section>
        </div>
      </div>
      {form === "paper" && (
        <Modal title="Register examination paper" onClose={close}>
          <form
            className="stack"
            onSubmit={(e) => {
              e.preventDefault();
              action(async () => {
                await api("/admin/papers", "POST", p);
                papers.reload();
                close();
                toast("Paper registered for review.");
              });
            }}
          >
            {[
              ["id", "Unique paper ID"],
              ["name", "Exam name"],
              ["year", "Year"],
              ["source", "Source citation or URL"],
            ].map(([k, label]) => (
              <Field label={label} key={k}>
                <input
                  required
                  type={k === "year" ? "number" : "text"}
                  value={p[k]}
                  onChange={(e) => P({ ...p, [k]: e.target.value })}
                />
              </Field>
            ))}
            <Select
              label="Track"
              value={p.track}
              opts={["BCS", "EEE"]}
              onChange={(x) => P({ ...p, track: x })}
            />
            <Select
              label="Organization"
              value={p.organization}
              placeholder="None"
              opts={orgs}
              onChange={(x) => P({ ...p, organization: x })}
            />
            <Status error={error} />
            <Button type="submit" variant="primary" disabled={busy}>
              Save paper
            </Button>
          </form>
        </Modal>
      )}
      {form === "marks" && (
        <Modal title="Edit 200-mark BCS distribution" onClose={close}>
          <form
            className="stack"
            onSubmit={(e) => {
              e.preventDefault();
              action(async () => {
                await api("/admin/marks", "PUT", marks);
                await refresh();
                close();
                toast("BCS distribution updated.");
              });
            }}
          >
            <div className="filters bare">
              {syllabus
                .filter((s) => s.track === "BCS")
                .map((s) => (
                  <Field key={s.id} label={s.name}>
                    <input
                      type="number"
                      min="0"
                      max="200"
                      required
                      value={marks[s.id] ?? 0}
                      onChange={(e) => M({ ...marks, [s.id]: +e.target.value })}
                    />
                  </Field>
                ))}
            </div>
            <Status error={error} />
            <Button type="submit" variant="primary" disabled={busy}>
              Save marks
            </Button>
          </form>
        </Modal>
      )}
      {form === "question" && (
        <Modal title={id ? "Edit question" : "New question"} onClose={close}>
          <Status {...question} />
          <form
            className="stack"
            onSubmit={(e) => {
              e.preventDefault();
              action(async () => {
                await api("/admin/questions", "POST", q);
                close();
                toast("Question saved for verification.");
              });
            }}
          >
            <div className="filters bare">
              <Select
                label="Track"
                value={q.track}
                opts={["BCS", "EEE"]}
                onChange={(x) =>
                  Q({ ...q, track: x, subject: "", topic: "", subtopic: "" })
                }
              />
              <Select
                label="Subject"
                value={q.subject}
                placeholder="Choose subject"
                opts={syllabus
                  .filter((s) => s.track === q.track)
                  .map((s) => ({ label: s.name, value: s.id }))}
                onChange={(x) =>
                  Q({ ...q, subject: x, topic: "", subtopic: "" })
                }
              />
              <Select
                label="Topic"
                value={q.topic}
                placeholder="Choose topic"
                opts={Object.keys(s?.groups || {})}
                onChange={(x) => Q({ ...q, topic: x, subtopic: "" })}
              />
              <Select
                label="Subtopic"
                value={q.subtopic}
                placeholder="Choose subtopic"
                opts={s?.groups[q.topic] || []}
                onChange={(x) => Q({ ...q, subtopic: x })}
              />
            </div>
            <Field label="Question">
              <textarea
                required
                value={q.text}
                onChange={(e) => Q({ ...q, text: e.target.value })}
              />
            </Field>
            <div className="filters bare">
              {q.options.map((v, i) => (
                <Field label={"Option " + "ABCD"[i]} key={i}>
                  <input
                    required
                    value={v}
                    onChange={(e) =>
                      Q({
                        ...q,
                        options: q.options.map((x, j) =>
                          j === i ? e.target.value : x,
                        ),
                      })
                    }
                  />
                </Field>
              ))}
            </div>
            <div className="filters bare">
              <Select
                label="Correct option"
                value={String(q.answer)}
                opts={[0, 1, 2, 3].map((i) => ({
                  value: String(i),
                  label: "ABCD"[i],
                }))}
                onChange={(x) => Q({ ...q, answer: +x })}
              />
              <Select
                label="Difficulty"
                value={q.difficulty}
                opts={["Easy", "Medium", "Hard"]}
                onChange={(x) => Q({ ...q, difficulty: x })}
              />
              <Select
                label="Kind"
                value={q.kind}
                opts={[
                  "Original practice",
                  "AI-generated",
                  "User-created",
                  "Previous-year",
                ]}
                onChange={(x) => Q({ ...q, kind: x })}
              />
              <Select
                label="Paper"
                value={q.paper_id || ""}
                placeholder="None"
                opts={papers.data
                  .filter((p) => p.track === q.track)
                  .map((x) => ({ value: x.id, label: x.name }))}
                onChange={(x) => Q({ ...q, paper_id: x })}
              />
            </div>
            <Field label="Explanation">
              <textarea
                required
                value={q.explanation}
                onChange={(e) => Q({ ...q, explanation: e.target.value })}
              />
            </Field>
            <Field label="Source">
              <input
                required
                value={q.source}
                onChange={(e) => Q({ ...q, source: e.target.value })}
              />
            </Field>
            {id && (
              <details>
                <summary>Version history ({history.data.length})</summary>
                {history.data.map((x) => (
                  <p key={x.id}>
                    {String(x.created_at).slice(0, 10)} · {x.snapshot.text} ·{" "}
                    {x.snapshot.status}
                  </p>
                ))}
              </details>
            )}
            <Status error={error} />
            <Button
              type="submit"
              variant="primary"
              disabled={busy || question.loading}
            >
              Save for review
            </Button>
          </form>
        </Modal>
      )}
    </>
  );
}
