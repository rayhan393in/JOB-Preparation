import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity,
  BarChart3,
  BookOpen,
  Bookmark,
  CalendarDays,
  ChartNoAxesCombined,
  ChevronDown,
  ChevronsUpDown,
  ClipboardCheck,
  ClipboardList,
  Clock3,
  FileClock,
  GraduationCap,
  LayoutDashboard,
  LibraryBig,
  LogIn,
  LogOut,
  Menu,
  Moon,
  NotebookPen,
  RotateCcw,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Sun,
  Target,
  X,
  Zap,
} from "lucide-react";
import "@fontsource-variable/dm-sans";
import "@fontsource-variable/fraunces";
import "./style.css";
import { api, Ctx, Button, Field, Modal, Status, useLoad } from "./ui";
import { Dashboard } from "./dashboard";
import { Syllabus, QuestionBank, PastPapers } from "./questions";
import { ExamBuilder, ExamRoom } from "./exams";
import { Routine, History, Notes, Revision, Settings } from "./planning";
import { Admin } from "./admin";
const navigation = [
  {
    title: "WORKSPACE",
    items: [
      ["dashboard", "Dashboard", LayoutDashboard],
      ["bcs", "BCS Preparation", GraduationCap],
      ["eee", "EEE Job Preparation", Zap],
      ["routine", "Daily Study Routine", CalendarDays],
    ],
  },
  {
    title: "PRACTICE",
    items: [
      ["daily", "Daily MCQ Exam", ClipboardCheck],
      ["manual", "Manual Examination", Settings2],
      ["bank", "Question Bank", LibraryBig],
      ["past", "Previous Year Questions", FileClock],
      ["mock", "Mock Examination", Target],
    ],
  },
  {
    title: "INSIGHTS",
    items: [
      ["history", "Historical Topic Analysis", ChartNoAxesCombined],
      ["weakness", "Weakness Recovery", Activity],
      ["revision", "Revision Center", RotateCcw],
      ["analytics", "Performance Analytics", BarChart3],
    ],
  },
  {
    title: "MY LIBRARY",
    items: [
      ["bookmarks", "My Bookmarks", Bookmark],
      ["notes", "My Notes", NotebookPen],
    ],
  },
];
const titles = Object.fromEntries(
  navigation.flatMap((g) => g.items.map(([p, t]) => [p, t])),
);
const initial = {
  user: null,
  syllabus: [],
  orgs: [],
  totals: [],
  settings: {},
};
const getRoute = () => window.location.hash.replace(/^#\/?/, "") || "dashboard";
function App() {
  const [route, R] = useState(getRoute),
    [boot, U] = useState<any>(initial),
    [activity, A] = useState<any>({ exams: [], routine: [] }),
    [load, L] = useState(""),
    [dark, D] = useState(localStorage.getItem("ep-theme") === "dark"),
    [lang, G] = useState(localStorage.getItem("ep-lang") || "en"),
    [track, T] = useState(localStorage.getItem("ep-track") || "Both"),
    [drawer, W] = useState(false),
    [auth, H] = useState(false),
    [search, S] = useState(false),
    [message, M] = useState(""),
    [profile, F] = useState(false);
  const active = useRef<any>(null),
    ensuring = useRef<any>(null),
    timeout = useRef<any>(null);
  const [path, query = ""] = route.split("?"),
    base = path.split("/")[0],
    params = new URLSearchParams(query);
  function go(to: string) {
    window.location.hash = to;
    R(to);
    W(false);
    S(false);
    window.scrollTo(0, 0);
  }
  function toast(m: string) {
    M(m);
    clearTimeout(timeout.current);
    timeout.current = setTimeout(() => M(""), 4200);
  }
  async function refresh() {
    const b = await api("/bootstrap");
    U(b);
    active.current = b.user;
    if (b.user) A(await api("/activity"));
    else A({ exams: [], routine: [] });
    return b;
  }
  async function ensure() {
    if (active.current) return active.current;
    if (!ensuring.current)
      ensuring.current = api("/auth/guest", "POST", {})
        .then(async (u) => {
          active.current = u;
          U((b: any) => ({ ...b, user: u }));
          return u;
        })
        .finally(() => {
          ensuring.current = null;
        });
    return ensuring.current;
  }
  function changeTrack(t: string) {
    T(t);
    localStorage.setItem("ep-track", t);
  }
  useEffect(() => {
    refresh()
      .then((b) => {
        if (b.settings.track && !localStorage.getItem("ep-track"))
          T(b.settings.track);
      })
      .catch((e) => L(e.message));
    const f = () => {
      R(getRoute());
      W(false);
      window.scrollTo(0, 0);
    };
    const key = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        S((x) => !x);
      }
    };
    window.addEventListener("hashchange", f);
    window.addEventListener("keydown", key);
    return () => {
      window.removeEventListener("hashchange", f);
      window.removeEventListener("keydown", key);
    };
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    localStorage.setItem("ep-theme", dark ? "dark" : "light");
  }, [dark]);
  useEffect(() => {
    localStorage.setItem("ep-lang", lang);
  }, [lang]);
  const ctx = {
    ...boot,
    ...activity,
    track,
    go,
    ensure,
    refresh,
    toast,
    auth: () => H(true),
    language: lang,
  };
  const title =
    titles[base] ||
    {
      settings: "Settings",
      exam: "Examination",
      admin: "Content workspace",
      manage: "Manage questions",
    }[base] ||
    "Dashboard";
  let content: React.ReactNode;
  switch (base) {
    case "bcs":
    case "eee":
      content = <Syllabus key={base} track={base.toUpperCase()} />;
      break;
    case "daily":
    case "manual":
    case "mock":
      content = <ExamBuilder key={route} mode={base} params={params} />;
      break;
    case "exam":
      content = <ExamRoom key={path} id={path.split("/")[1]} />;
      break;
    case "bank":
    case "bookmarks":
    case "manage":
      content = (
        <QuestionBank
          key={base}
          params={params}
          book={base === "bookmarks"}
          manage={base === "manage" && boot.user?.role === "admin"}
        />
      );
      break;
    case "past":
      content = <PastPapers />;
      break;
    case "routine":
      content = <Routine />;
      break;
    case "history":
      content = <History />;
      break;
    case "weakness":
    case "revision":
      content = <Revision key={base} weak={base === "weakness"} />;
      break;
    case "analytics":
      content = <Dashboard key="analytics" full />;
      break;
    case "notes":
      content = <Notes />;
      break;
    case "settings":
      content = (
        <Settings
          key={JSON.stringify(boot.settings)}
          dark={dark}
          setDark={D}
          language={lang}
          setLanguage={G}
        />
      );
      break;
    case "admin":
      content = <Admin params={params} />;
      break;
    default:
      content = <Dashboard key="dashboard" />;
  }
  return (
    <Ctx.Provider value={ctx}>
      <div className="shell">
        {drawer && (
          <button
            className="drawer-scrim"
            aria-label="Close sidebar"
            onClick={() => W(false)}
          />
        )}
        <aside className={"sidebar " + (drawer ? "shown" : "")}>
          <a href="#dashboard" className="brand">
            <span className="brand-icon">
              <BookOpen size={22} strokeWidth={1.8} />
              <i />
            </span>
            <span>
              <b>
                ExamPrep <em>BD</em>
              </b>
              <small>YOUR STUDY COMPANION</small>
            </span>
          </a>
          <div className="sidebar-scroll">
            <div className="track-picker">
              <span className="track-picker-icon">
                <GraduationCap size={17} />
              </span>
              <div>
                <small>Preparation track</small>
                <strong>{track === "Both" ? "BCS + EEE" : track}</strong>
              </div>
              <ChevronsUpDown size={15} />
              <select
                aria-label="Preparation track"
                value={track}
                onChange={(e) => changeTrack(e.target.value)}
              >
                <option value="Both">BCS + EEE</option>
                <option>BCS</option>
                <option>EEE</option>
              </select>
            </div>
            <nav aria-label="Main navigation">
              {navigation.map((g) => (
                <div className="nav-group" key={g.title}>
                  <div className="nav-title">{g.title}</div>
                  {g.items.map(([p, t, Icon]: any) => (
                    <a
                      href={"#" + p}
                      key={p}
                      className={base === p ? "active" : ""}
                      aria-current={base === p ? "page" : undefined}
                    >
                      <Icon size={16} strokeWidth={1.75} />
                      <span>{t}</span>
                    </a>
                  ))}
                </div>
              ))}
            </nav>
          </div>
          <div className="sidebar-bottom">
            <a href="#settings" className={base === "settings" ? "active" : ""}>
              <Settings2 size={17} /> Settings
            </a>
            {boot.user?.role === "admin" && (
              <a href="#admin" className={base === "admin" ? "active" : ""}>
                <ShieldCheck size={17} /> Content workspace
              </a>
            )}
          </div>
        </aside>
        <div className="workspace">
          <header className="topbar">
            <div className="breadcrumbs">
              <button
                className="icon-btn hamburger"
                aria-label="Open menu"
                onClick={() => W(!drawer)}
              >
                <Menu size={21} />
              </button>
              <span className="crumb-root">Workspace</span>
              <span className="crumb-divider">/</span>
              <strong>{title}</strong>
            </div>
            <div className="top-actions">
              <button className="search-button" onClick={() => S(true)}>
                <Search size={16} />
                <span>Search questions...</span>
                <kbd>Ctrl K</kbd>
              </button>
              <button
                className="icon-btn theme-btn"
                title={dark ? "Light theme" : "Dark theme"}
                aria-label={
                  dark ? "Switch to light mode" : "Switch to dark mode"
                }
                onClick={() => D(!dark)}
              >
                {dark ? <Sun size={18} /> : <Moon size={18} />}
              </button>
              <div className="top-rule" />
              <div className="profile-wrap">
                <button
                  className="profile"
                  aria-label="Account menu"
                  onClick={() => F(!profile)}
                >
                  <span>
                    {boot.user?.role === "student" ||
                    boot.user?.role === "admin"
                      ? boot.user.name.slice(0, 2).toUpperCase()
                      : "EP"}
                  </span>
                  <ChevronDown size={13} />
                </button>
                {profile && (
                  <div className="profile-menu panel">
                    <strong>{boot.user?.name || "Welcome, learner"}</strong>
                    <small>{boot.user?.email || "Practice workspace"}</small>
                    {(!boot.user || boot.user.role === "guest") && (
                      <Button
                        variant="subtle"
                        onClick={() => {
                          F(false);
                          H(true);
                        }}
                      >
                        <LogIn size={15} /> Sign in or register
                      </Button>
                    )}
                    {boot.user && (
                      <Button
                        variant="text"
                        onClick={async () => {
                          try {
                            await api("/auth/logout", "POST", {});
                            await refresh();
                            F(false);
                            go("dashboard");
                            toast("Signed out.");
                          } catch (e) {
                            toast(e.message);
                          }
                        }}
                      >
                        <LogOut size={15} /> Sign out
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </header>
          <main className="main" id="main">
            <Status error={load} />
            {content}
          </main>
        </div>
      </div>
      {auth && (
        <Auth
          close={() => H(false)}
          done={async () => {
            const b = await refresh();
            if (b.settings.track) changeTrack(b.settings.track);
            H(false);
            toast("You’re signed in.");
          }}
        />
      )}
      {search && <SearchBox close={() => S(false)} go={go} />}
      <div className={message ? "toast visible" : "toast"} role="status">
        {message}
      </div>
    </Ctx.Provider>
  );
}
function Auth({ close, done }: any) {
  const [mode, M] = useState("login"),
    [error, E] = useState(""),
    [busy, B] = useState(false);
  return (
    <Modal
      title={mode === "login" ? "Sign in to ExamPrep BD" : "Create an account"}
      onClose={close}
    >
      <form
        className="stack"
        onSubmit={async (e) => {
          e.preventDefault();
          E("");
          B(true);
          const values = Object.fromEntries(new FormData(e.currentTarget));
          try {
            await api("/auth/" + mode, "POST", values);
            await done();
          } catch (e) {
            E(e.message);
          } finally {
            B(false);
          }
        }}
      >
        <p className="muted">
          Save your study progress and come back on any device. Guest activity
          isn’t transferred to a new account.
        </p>
        {mode === "register" && (
          <Field label="Name">
            <input autoComplete="name" name="name" required maxLength={60} />
          </Field>
        )}
        <Field label="Email">
          <input
            type="email"
            autoComplete="email"
            name="email"
            required
            autoFocus
          />
        </Field>
        <Field label="Password">
          <input
            type="password"
            name="password"
            autoComplete={
              mode === "login" ? "current-password" : "new-password"
            }
            required
            minLength={8}
            maxLength={128}
          />
        </Field>
        <Status error={error} />
        <Button variant="primary" type="submit" disabled={busy}>
          {busy
            ? "Please wait…"
            : mode === "login"
              ? "Sign in"
              : "Create account"}
        </Button>
        <Button
          variant="text"
          onClick={() => {
            M(mode === "login" ? "register" : "login");
            E("");
          }}
        >
          {mode === "login"
            ? "New here? Create an account"
            : "Already have an account? Sign in"}
        </Button>
      </form>
    </Modal>
  );
}
function SearchBox({ close, go }: any) {
  const [q, Q] = useState("");
  const data = useLoad<any>(
    q.trim().length >= 2
      ? "/questions?search=" + encodeURIComponent(q.trim())
      : null,
    { data: [], total: 0 },
  );
  return (
    <Modal title="Search questions" onClose={close}>
      <form
        className="stack"
        onSubmit={(e) => {
          e.preventDefault();
          go("bank?search=" + encodeURIComponent(q.trim()));
        }}
      >
        <div className="input-search">
          <Search size={18} />
          <input
            autoFocus
            aria-label="Search query"
            placeholder="Try ‘transformer’ or ‘constitution’"
            value={q}
            onChange={(e) => Q(e.target.value)}
          />
        </div>
        <Status {...data} />
        {q.trim().length >= 2 && !data.loading && (
          <div className="stack">
            {data.data.data.slice(0, 4).map((item) => (
              <button
                type="button"
                className="search-result"
                key={item.id}
                onClick={() =>
                  go(
                    "bank?track=" +
                      item.track +
                      "&search=" +
                      encodeURIComponent(item.text.slice(0, 94)),
                  )
                }
              >
                <span className="tag lavender">{item.track}</span>
                <span>{item.text}</span>
              </button>
            ))}
            {!data.data.total && (
              <p className="muted">No matching questions.</p>
            )}
          </div>
        )}
        <Button variant="primary" type="submit">
          Open Question Bank
        </Button>
      </form>
    </Modal>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
