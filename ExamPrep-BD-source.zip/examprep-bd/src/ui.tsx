import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";
import {
  ArrowUpRight,
  ChevronRight,
  Inbox,
  LoaderCircle,
  X,
} from "lucide-react";
export const api = async (path: string, method = "GET", data?: any) => {
  const r = await fetch("/api" + path, {
    method,
    headers: { "Content-Type": "application/json", "X-ExamPrep": "1" },
    body: data === undefined ? undefined : JSON.stringify(data),
  });
  const body = await r.json();
  if (!r.ok)
    throw Object.assign(new Error(body.error || "Request failed."), {
      status: r.status,
    });
  return body;
};
export type Subject = {
  id: string;
  name: string;
  bn: string;
  track: string;
  marks: number;
  groups: Record<string, string[]>;
};
export type AppData = {
  user: any;
  syllabus: Subject[];
  orgs: string[];
  totals: { track: string; count: number }[];
  settings: any;
  exams: any[];
  routine: any[];
  track: string;
  go: (route: string) => void;
  ensure: () => Promise<any>;
  refresh: () => Promise<any>;
  toast: (msg: string) => void;
  auth: () => void;
  language: string;
};
export const Ctx = createContext<AppData>(null!);
export const useApp = () => useContext(Ctx);
export const dateKey = (x: any = new Date()) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Dhaka",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(x));
export function dateLabel(
  x: any = new Date(),
  opts: Intl.DateTimeFormatOptions = {
    weekday: "long",
    month: "long",
    day: "numeric",
  },
) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Dhaka",
    ...opts,
  }).format(new Date(x));
}
export function useLoad<T = any>(path: string | null, initial: T) {
  const [data, setData] = useState<T>(initial),
    [state, setState] = useState({ loading: !!path, error: "" }),
    [version, setVersion] = useState(0);
  useEffect(() => {
    if (!path) {
      setData(initial);
      setState({ loading: false, error: "" });
      return;
    }
    let active = true;
    setState({ loading: true, error: "" });
    api(path)
      .then((d) => {
        if (active) {
          setData(d);
          setState({ loading: false, error: "" });
        }
      })
      .catch((e) => {
        if (active) setState({ loading: false, error: e.message });
      });
    return () => {
      active = false;
    };
  }, [path, version]);
  return { data, ...state, reload: () => setVersion((x) => x + 1) };
}
export const qstr = (x: any) =>
  new URLSearchParams(
    Object.entries(x)
      .filter(([, v]) => v !== "" && v !== undefined && v !== null)
      .map(([k, v]) => [k, String(v)]),
  ).toString();
export function Modal({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  useEffect(() => {
    const f = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", f);
    return () => document.removeEventListener("keydown", f);
  }, [onClose]);
  return (
    <div
      className="veil"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <section
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <header>
          <h2>{title}</h2>
          <button
            className="icon-btn"
            aria-label="Close dialog"
            onClick={onClose}
          >
            <X size={19} />
          </button>
        </header>
        {children}
      </section>
    </div>
  );
}
export function Heading({
  title,
  subtitle,
  eyebrow = "STUDY WORKSPACE",
  action,
}: {
  title: string;
  subtitle?: string;
  eyebrow?: string;
  action?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        {subtitle && <p className="muted">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}
export function Button({
  children,
  onClick,
  type = "button",
  variant = "",
  disabled = false,
}: any) {
  return (
    <button
      className={"button " + variant}
      onClick={onClick}
      type={type}
      disabled={disabled}
    >
      {children}
    </button>
  );
}
export function LinkButton({
  children,
  to,
  variant = "text",
}: {
  children: ReactNode;
  to: string;
  variant?: string;
}) {
  return (
    <a className={"button " + variant} href={"#" + to}>
      {children}
      {variant === "text" ? (
        <ChevronRight size={15} />
      ) : (
        <ArrowUpRight size={16} />
      )}
    </a>
  );
}
export function Field({ label, children }: any) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
    </label>
  );
}
export function Select({ label, value, opts, onChange, placeholder }: any) {
  return (
    <Field label={label}>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        {placeholder && <option value="">{placeholder}</option>}
        {opts.map((x: any) =>
          typeof x === "string" ? (
            <option key={x}>{x}</option>
          ) : (
            <option key={x.value} value={x.value}>
              {x.label}
            </option>
          ),
        )}
      </select>
    </Field>
  );
}
export function Empty({ title, description, children }: any) {
  return (
    <div className="empty">
      <div className="icon-tile lavender">
        <Inbox size={21} />
      </div>
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      {children}
    </div>
  );
}
export function Status({ loading, error }: any) {
  return error ? (
    <p className="error" role="alert">
      {error}
    </p>
  ) : loading ? (
    <p className="loading">
      <LoaderCircle size={16} className="spin" /> Loading…
    </p>
  ) : null;
}
export const scoreClass = (n: number | null) =>
  n === null
    ? "No estimate"
    : n >= 80
      ? "Very High"
      : n >= 65
        ? "High"
        : n >= 40
          ? "Medium"
          : "Low";
