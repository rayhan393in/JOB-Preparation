import { useEffect, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Bookmark,
  ChevronDown,
  CheckCircle2,
  FileQuestion,
  Flag,
  Search,
} from "lucide-react";
import {
  api,
  useApp,
  Heading,
  Button,
  LinkButton,
  Field,
  Select,
  Empty,
  Status,
  useLoad,
  qstr,
  Modal,
} from "./ui";
export function Syllabus({ track }: { track: string }) {
  const { syllabus, language, go } = useApp();
  const data = syllabus.filter((s) => s.track === track);
  const [query, Q] = useState("");
  const shown = data.filter((s) =>
    [s.name, s.bn, ...Object.values(s.groups).flat()]
      .join(" ")
      .toLowerCase()
      .includes(query.toLowerCase()),
  );
  return (
    <>
      <Heading
        title={track === "BCS" ? "BCS Preparation" : "EEE Job Preparation"}
        subtitle={
          track === "BCS"
            ? "Explore the configurable 200-mark preliminary syllabus."
            : "Explore the technical and general syllabus for electrical recruitment exams."
        }
        eyebrow={`${track} PREPARATION`}
        action={
          <LinkButton to={`manual?track=${track}`} variant="primary">
            Build a practice exam
          </LinkButton>
        }
      />
      <section className="panel block">
        <div className="toolbar">
          <div>
            <h2>Subject syllabus</h2>
            <p className="muted">
              {data.length} subjects ·{" "}
              {data.reduce(
                (n, s) => n + Object.values(s.groups).flat().length,
                0,
              )}{" "}
              subtopics
            </p>
          </div>
          <div className="input-search">
            <Search size={16} />
            <input
              value={query}
              onChange={(e) => Q(e.target.value)}
              placeholder="Find a topic…"
              aria-label="Find a topic"
            />
          </div>
        </div>
        <div className="syllabus-list">
          {shown.map((s) => (
            <details key={s.id} open={query ? true : undefined}>
              <summary>
                <span
                  className={
                    "icon-tile " + (track === "BCS" ? "lavender" : "gold")
                  }
                >
                  <BookOpen size={17} />
                </span>
                <span>
                  <strong>{language === "bn" ? s.bn : s.name}</strong>
                  <small>
                    {Object.values(s.groups).flat().length} subtopics
                  </small>
                </span>
                {track === "BCS" && (
                  <span className="tag">{s.marks} marks</span>
                )}
                <ChevronDown size={16} />
              </summary>
              <div className="syllabus-groups">
                {Object.entries(s.groups).map(([g, items]) => (
                  <details key={g}>
                    <summary>
                      {g} <ChevronDown size={14} />
                    </summary>
                    <div className="topic-pills">
                      {items.map((t) => (
                        <button
                          key={t}
                          onClick={() =>
                            go(
                              "bank?" +
                                qstr({
                                  track,
                                  subject: s.id,
                                  topic: g,
                                  subtopic: t,
                                }),
                            )
                          }
                        >
                          {t} <ArrowRight size={12} />
                        </button>
                      ))}
                    </div>
                  </details>
                ))}
              </div>
            </details>
          ))}
        </div>
        {!shown.length && <Empty title="No matching topics" />}
      </section>
    </>
  );
}
export function Filters({ v, on, organization = false, full = true }: any) {
  const { syllabus, orgs } = useApp();
  const subjects = syllabus.filter(
    (s) => !v.track || v.track === "Both" || s.track === v.track,
  );
  const selected = subjects.find((s) => s.id === v.subject),
    topics = Object.keys(selected?.groups || {}),
    subs = v.topic
      ? selected?.groups[v.topic] || []
      : Object.values(selected?.groups || {}).flat();
  return (
    <>
      <Select
        label="Track"
        value={v.track || "Both"}
        opts={["Both", "BCS", "EEE"]}
        onChange={(x) =>
          on({
            track: x,
            subject: "",
            topic: "",
            subtopic: "",
            organization: "",
          })
        }
      />
      <Select
        label="Subject"
        value={v.subject || ""}
        placeholder="All subjects"
        opts={subjects.map((s) => ({ value: s.id, label: s.name }))}
        onChange={(x) => on({ subject: x, topic: "", subtopic: "" })}
      />
      {full && (
        <>
          <Select
            label="Topic"
            value={v.topic || ""}
            placeholder="All topics"
            opts={topics}
            onChange={(x) => on({ topic: x, subtopic: "" })}
          />
          <Select
            label="Subtopic"
            value={v.subtopic || ""}
            placeholder="All subtopics"
            opts={subs}
            onChange={(x) => on({ subtopic: x })}
          />
        </>
      )}
      {organization && v.track !== "BCS" && (
        <Select
          label="Organization"
          value={v.organization || ""}
          placeholder="All organizations"
          opts={orgs}
          onChange={(x) => on({ organization: x })}
        />
      )}
    </>
  );
}
export function QuestionBank({
  params,
  book = false,
  manage = false,
}: {
  params: URLSearchParams;
  book?: boolean;
  manage?: boolean;
}) {
  const { track, syllabus, user, ensure, refresh, toast, go } = useApp();
  const pkey = params.toString();
  const [filters, F] = useState<any>({ track, ...Object.fromEntries(params) });
  const [page, P] = useState(1),
    [report, R] = useState(""),
    [reason, B] = useState(""),
    [error, E] = useState("");
  useEffect(() => {
    F({ track, ...Object.fromEntries(params) });
    P(1);
  }, [pkey, track]);
  const source = useLoad<any>(
    "/questions?" +
      qstr({
        ...filters,
        page,
        book: book ? "1" : "",
        admin: manage ? "1" : "",
      }),
    { data: [], total: 0 },
  );
  const bookmarks = useLoad<string[]>(user ? "/bookmarks" : null, []);
  const [open, O] = useState("");
  function set(v: any) {
    F((s: any) => ({ ...s, ...v }));
    P(1);
  }
  const save = async (id: string) => {
    try {
      await ensure();
      await api("/bookmarks/" + id, "POST", {
        saved: !bookmarks.data.includes(id),
      });
      bookmarks.reload();
      if (book) source.reload();
      toast(
        bookmarks.data.includes(id)
          ? "Bookmark removed."
          : "Question bookmarked.",
      );
    } catch (e) {
      toast(e.message);
    }
  };
  return (
    <>
      <Heading
        title={
          book ? "My Bookmarks" : manage ? "Manage Questions" : "Question Bank"
        }
        eyebrow={book ? "MY LIBRARY" : "PRACTICE"}
        subtitle={
          book
            ? "Return to the questions you’ve saved."
            : "Search, filter and review BCS and EEE practice questions."
        }
        action={
          manage ? (
            <LinkButton to="admin" variant="primary">
              Content workspace
            </LinkButton>
          ) : (
            <LinkButton to="manual" variant="primary">
              Build a practice exam
            </LinkButton>
          )
        }
      />
      <div className="panel block">
        <div className="input-search">
          <Search size={17} />
          <input
            placeholder="Search question text…"
            aria-label="Search question text"
            value={filters.search || ""}
            onChange={(e) => set({ search: e.target.value })}
          />
        </div>
        <div className="filters bank-filters">
          <Filters v={filters} on={set} organization />
          <Select
            label="Difficulty"
            placeholder="All levels"
            opts={["Easy", "Medium", "Hard"]}
            value={filters.difficulty || ""}
            onChange={(x) => set({ difficulty: x })}
          />
        </div>
      </div>
      <Status {...source} />
      <div className="section-bar">
        <div className="section-title">
          {source.data.total.toLocaleString()} questions
        </div>
        {source.data.total > 0 && (
          <span className="muted">
            Page {page} of {Math.ceil(source.data.total / 8)}
          </span>
        )}
      </div>
      <div className="stack">
        {source.data.data.map((q) => (
          <article className="panel question-card" key={q.id}>
            <div className="question-top">
              <div className="tagline">
                <span
                  className={"tag " + (q.track === "BCS" ? "lavender" : "gold")}
                >
                  {q.track}
                </span>
                <span className="tag">{q.kind}</span>
                <span className="tag">{q.status}</span>
                <span className="tag">{q.difficulty}</span>
              </div>
              <button
                className={
                  "icon-btn " +
                  (bookmarks.data.includes(q.id) ? "selected" : "")
                }
                aria-label={
                  bookmarks.data.includes(q.id)
                    ? "Remove bookmark"
                    : "Bookmark question"
                }
                onClick={() => save(q.id)}
              >
                <Bookmark
                  size={19}
                  fill={bookmarks.data.includes(q.id) ? "currentColor" : "none"}
                />
              </button>
            </div>
            <small className="muted">
              {syllabus.find((s) => s.id === q.subject)?.name} / {q.subtopic}
            </small>
            <h3>{q.text}</h3>
            <div className="question-options">
              {q.options.map((v, i) => (
                <div
                  key={i}
                  className={
                    open === q.id && i === q.answer ? "answer-good" : ""
                  }
                >
                  <b>{"ABCD"[i]}</b>
                  {v}
                </div>
              ))}
            </div>
            {open === q.id && (
              <div className="explanation">
                <strong>Answer: {"ABCD"[q.answer]}</strong>
                <p>{q.explanation}</p>
                <small>
                  Source: {q.source}
                  {q.paper_name ? ` · ${q.paper_name} (${q.year})` : ""}
                </small>
              </div>
            )}
            <footer>
              <Button
                variant="subtle"
                onClick={() => O(open === q.id ? "" : q.id)}
              >
                {open === q.id ? "Hide explanation" : "Show answer"}{" "}
                <ChevronDown size={15} />
              </Button>
              <Button
                variant="text"
                onClick={() => {
                  R(q.id);
                  B("");
                  E("");
                }}
              >
                <Flag size={15} /> Report
              </Button>
              {manage && (
                <>
                  <LinkButton to={"admin?edit=" + q.id}>Edit</LinkButton>
                  <Button
                    variant="text"
                    onClick={async () => {
                      try {
                        await api("/admin/questions/" + q.id, "PATCH", {
                          verified: q.status !== "Verified",
                        });
                        source.reload();
                        await refresh();
                        toast("Verification updated.");
                      } catch (e) {
                        toast(e.message);
                      }
                    }}
                  >
                    {q.status === "Verified" ? "Unverify" : "Verify"}
                  </Button>
                  <Button
                    variant="text danger"
                    onClick={async () => {
                      if (!confirm("Archive this question?")) return;
                      try {
                        await api("/admin/questions/" + q.id, "PATCH", {
                          archived: true,
                        });
                        source.reload();
                        await refresh();
                        toast("Question archived.");
                      } catch (e) {
                        toast(e.message);
                      }
                    }}
                  >
                    Archive
                  </Button>
                </>
              )}
            </footer>
          </article>
        ))}
      </div>
      {!source.loading && !source.error && !source.data.total && (
        <section className="panel">
          <Empty
            title={book ? "No saved questions" : "No matching questions"}
            description={
              book
                ? "Use the bookmark icon in the question bank."
                : "Try removing a filter or finding a different topic."
            }
          >
            {book && <LinkButton to="bank">Browse question bank</LinkButton>}
          </Empty>
        </section>
      )}
      {source.data.total > 8 && (
        <div className="pager">
          <Button
            variant="subtle"
            disabled={page === 1}
            onClick={() => {
              P(page - 1);
              window.scrollTo(0, 0);
            }}
          >
            <ArrowLeft size={16} /> Previous
          </Button>
          <span>
            {page} / {Math.ceil(source.data.total / 8)}
          </span>
          <Button
            variant="subtle"
            disabled={page * 8 >= source.data.total}
            onClick={() => {
              P(page + 1);
              window.scrollTo(0, 0);
            }}
          >
            Next <ArrowRight size={16} />
          </Button>
        </div>
      )}
      {report && (
        <Modal title="Report a question" onClose={() => R("")}>
          <form
            className="stack"
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                await ensure();
                await api("/report/" + report, "POST", { reason });
                R("");
                toast("Report submitted for review.");
              } catch (e) {
                E(e.message);
              }
            }}
          >
            <Field label="What needs correcting?">
              <textarea
                required
                value={reason}
                onChange={(e) => B(e.target.value)}
              />
            </Field>
            <Status error={error} />
            <Button type="submit" variant="primary">
              Send report
            </Button>
          </form>
        </Modal>
      )}
    </>
  );
}
export function PastPapers() {
  const { track, orgs, ensure, go, toast } = useApp();
  const source = useLoad<any[]>("/papers", []);
  const [t, T] = useState(track),
    [org, O] = useState("");
  const [busy, B] = useState(false);
  const papers = source.data.filter(
    (p) => (t === "Both" || p.track === t) && (!org || p.organization === org),
  );
  return (
    <>
      <Heading
        title="Previous Year Questions"
        eyebrow="PRACTICE"
        subtitle="Practice directly from reviewed past papers. Only verified papers are listed here."
      />
      <div className="panel filters">
        <Select
          label="Track"
          value={t}
          opts={["Both", "BCS", "EEE"]}
          onChange={(x) => {
            T(x);
            O("");
          }}
        />
        <Select
          label="Organization"
          value={org}
          opts={orgs}
          placeholder="All organizations"
          onChange={O}
        />
      </div>
      <Status {...source} />
      {papers.length ? (
        <div className="stack">
          {papers.map((p) => (
            <section className="panel block toolbar" key={p.id}>
              <div>
                <h2>{p.name}</h2>
                <p className="muted">
                  {p.track} · {p.year} · {p.questions} verified questions
                </p>
                <p className="muted">Source: {p.source}</p>
              </div>
              <div className="row">
                <LinkButton
                  to={"bank?" + qstr({ track: p.track, paper: p.id })}
                >
                  Browse questions
                </LinkButton>
                <Button
                  variant="primary"
                  disabled={busy || !p.questions}
                  onClick={async () => {
                    B(true);
                    try {
                      await ensure();
                      const a = await api("/exams", "POST", {
                        mode: "past",
                        track: p.track,
                        paper: p.id,
                        duration: p.track === "BCS" ? 120 : 60,
                      });
                      go("exam/" + a.id);
                    } catch (e) {
                      toast(e.message);
                    } finally {
                      B(false);
                    }
                  }}
                >
                  Take paper
                </Button>
              </div>
            </section>
          ))}
        </div>
      ) : (
        !source.loading && (
          <div className="panel">
            <Empty
              title="No verified papers available"
              description="This workspace has not added a verified paper for the selected filters. Practice questions are never presented as past papers."
            >
              <LinkButton to="bank">Browse practice questions</LinkButton>
            </Empty>
          </div>
        )
      )}
    </>
  );
}
