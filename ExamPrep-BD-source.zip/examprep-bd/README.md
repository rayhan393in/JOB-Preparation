# ExamPrep BD

A working BCS and EEE exam-preparation workspace. This release builds the Phase 1–4 foundation, then adds the timed exam engine and study workflows. It is a runnable preview, not a claim of a production deployment or a fully verified question bank.

## Run locally

Requires Node.js 20+ and npm.

```sh
npm ci
npm run build
npm start
```

Open `http://localhost:5173`. Use **Start daily exam** or create an account from the avatar menu. `npm run dev` runs the Node API with Vite middleware. `npm test` runs grading, prioritization, and API integration tests. `SCALE_TEST=1 npm test` additionally imports and paginates through 10,000 synthetic fixtures inside an isolated database that is deleted after testing.

The default database is PostgreSQL via PGlite, persisted under `.runtime/examprep`. The React app and the API are served from the same origin. The dashboard may show explicitly labeled demo metrics before any account or guest activity. Guest activity belongs to a browser session and is not transferred to an account.

## Administrator setup

1. Register an account you control and confirm ownership out of band. The app does not currently send email verification messages.
2. Set `ADMIN_EMAIL` to that **already registered** account and restart the server. Remove the variable after promotion. Do not set it to an address you have not independently verified. Never share an administrator session.
3. Sign in. **Content workspace** appears at the bottom of the navigation.

### Import and provenance

- Download the CSV template from the content workspace or use JSON with an `options` array. Excel sheets use the same header row as CSV. Topic names are the group names shown in the syllabus. `subject` is the syllabus slug, such as `math`, `english`, `machines` or `electronics`. Inspect `/api/bootstrap` for the definitive IDs and valid taxonomy.
- Use answer letters A–D for CSV/XLSX; JSON supports A–D or zero-based numeric indices. Import accepts up to 2,500 rows per batch, validates all rows, and refuses the entire batch if validation fails.
- For past papers, register a paper ID and cite the original paper, import its questions with `kind=Previous-year` and `paper_id`, then verify the questions and paper separately. Review original and AI-generated questions for factual accuracy before publication. Verification is a human editorial action, not an automatic factual check.
- Only verified past questions mapped to verified papers contribute to historical statistics. A priority estimate can use syllabus and performance signals even when verified paper counts are absent. Frequency share uses the available verified questions in the track, not all questions that have ever been asked. Repeats match exact normalized wording within a topic.
- The shipped inventory contains 58 sample practice questions (25 BCS and 33 EEE), and **no verified historical papers**. A BCS 200-mark mock requires sufficient published inventory for each subject; the server reports a shortfall rather than reusing or generating questions. A past-paper attempt uses the available verified items; operators should verify completeness from the original source before sharing it as a full paper.

## Implementation and checks

- React, TypeScript, Tailwind, Recharts and Lucide; responsive UI, light/dark appearance, Bangla question and syllabus content.
- PostgreSQL taxonomy, question and source records, profiles, hashed sessions, exam attempts, saved answers, editable routines, notes, bookmarks, revision and moderation records. RLS is enabled for direct table access; the server database account must have access and enforces ownership in the API.
- Daily, manual, past-paper and mock modes; server deadlines, autosave, review flags, penalty scoring, and result review. Daily exam distribution uses eligible bucket targets with inventory-aware fallbacks.
- Routine generation uses daily study time, distinct subjects, preparation tracks, priority, due reviews, unfinished work, rotation, rest days and target date. Manual changes require confirmation before regeneration.
- Review intervals are 1, 3, 7, 15 and 30 days. An incorrect answer resets the interval; subsequent correct practice advances it.
- Build and integration tests cover account/login persistence, user isolation, daily exams, scoring, topic analytics, revision, routine overwrite guard, CSV/XLSX/JSON validation, and verified-history gating. The capacity test is a storage/import check, not a production load test.

## Hosted deployment

No existing Supabase or Vercel project was changed. Set `DATABASE_URL` to a managed PostgreSQL connection string (including a suitable Supabase Postgres connection string) to use external storage. The server applies `server/schema.sql` and seeds reference data on startup. For a production environment, use a dedicated database/schema, split migration and app credentials, enforce TLS, and configure backups. Serve the API behind HTTPS on the same origin as the frontend. A static-only Vercel deployment of `dist/` does not provide the Node API; host the server on a Node runtime or configure a same-origin proxy to it.

Before a public launch, add verified account recovery and email verification, operational monitoring, abuse protection and backups, collect licensed past papers, and test the intended managed database and hosting environment. Full Bengali UI translation, richer analytics variants and a full editorial bulk-edit/recovery suite are follow-on work.
