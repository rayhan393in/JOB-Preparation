import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwind from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwind()],
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (
            id.includes("/node_modules/") &&
            /\/(recharts|d3-[^/]+|victory-vendor|recharts-scale|react-smooth)\//.test(
              id,
            )
          )
            return "charts";
          if (
            id.includes("/node_modules/react-dom/") ||
            id.includes("/node_modules/react/")
          )
            return "react";
        },
      },
    },
  },
});
