import assert from "node:assert/strict";
import { test } from "node:test";
import { grade, selectExam, priority, day } from "./logic.mjs";
import { syllabus, sample } from "./content.mjs";
test("grading distinguishes skipped, wrong, and right; uses configurable penalty", () => {
  const g = grade(
    [{ answer: 1 }, { answer: 1 }, { answer: 2 }],
    { 0: { choice: 1 }, 1: { choice: 3 } },
    0.5,
  );
  assert.deepEqual(
    [g.correct, g.incorrect, g.unanswered, g.score, g.accuracy],
    [1, 1, 1, 0.5, 50],
  );
});
test("daily exams require at least two distinct subjects and unique questions", () => {
  const b = sample.filter((q) => q.track === "BCS");
  const d = selectExam(b, {
    count: 25,
    mode: "daily",
    track: "BCS",
    subjects: syllabus,
  });
  assert.equal(new Set(d.map((q) => q.id)).size, 25);
  assert.ok(new Set(d.map((q) => q.subject)).size >= 2);
  assert.throws(
    () =>
      selectExam(
        b.filter((q) => q.subject === "math"),
        { count: 3, mode: "daily" },
      ),
    /two subjects/,
  );
});
test("full BCS mock refuses short inventory rather than filling with invented questions", () =>
  assert.throws(
    () =>
      selectExam(sample, {
        mode: "mock",
        track: "BCS",
        subjects: syllabus.filter((s) => s.track === "BCS"),
      }),
    /needs/,
  ));
test("priority uses only available signals and normalized custom weights", () => {
  assert.equal(priority([60, 40, 100, 50], [35, 25, 20, 20]), 61);
  assert.equal(priority([null, null, 80, null], [35, 25, 20, 20]), 80);
  assert.equal(priority([null, null, null, null], [35, 25, 20, 20]), null);
});
test("canonical syllabus tracks, marks and sample provenance", () => {
  assert.equal(syllabus.filter((s) => s.track === "BCS").length, 10);
  assert.equal(syllabus.filter((s) => s.track === "EEE").length, 15);
  assert.equal(
    syllabus.reduce((n, s) => n + s.marks, 0),
    200,
  );
  assert.ok(
    sample.every(
      (x) =>
        x.status === "Sample" &&
        x.kind !== "Previous-year" &&
        new Set(x.options).size === 4,
    ),
  );
});
test("day boundary is Asia/Dhaka", () =>
  assert.equal(day(new Date("2026-11-18T18:00:00Z")), "2026-11-19"));
