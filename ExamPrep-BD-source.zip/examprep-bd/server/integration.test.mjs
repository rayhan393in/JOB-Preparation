import assert from "node:assert/strict";
import { test } from "node:test";
import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import ExcelJS from "exceljs";
let port = 0;
const launch = (db, email) =>
  new Promise((resolve, reject) => {
    const p = spawn(process.execPath, ["server/index.mjs"], {
      env: {
        ...process.env,
        DATABASE_URL: "",
        PORT: "0",
        LOCAL_DB_PATH: db,
        ADMIN_EMAIL: email || "",
      },
      stdio: ["ignore", "pipe", "pipe"],
    });
    let logs = "";
    p.stdout.on("data", (buf) => {
      logs += buf;
      const m = logs.match(/ready on port (\d+)/);
      if (m) {
        port = +m[1];
        resolve(p);
      }
    });
    p.stderr.on("data", (buf) => {
      logs += buf;
    });
    p.once("exit", (n) => reject(Error(`App exited ${n}: ${logs}`)));
  });
const stop = (p) =>
  p
    ? new Promise((r) => {
        if (p.exitCode !== null) return r();
        p.once("exit", r);
        p.kill();
      })
    : Promise.resolve();
function client() {
  let cookie = "";
  return async (route, method = "GET", body, status = 200) => {
    const r = await fetch(`http://127.0.0.1:${port}/api${route}`, {
      method,
      headers: {
        "content-type": "application/json",
        "x-examprep": "1",
        cookie,
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const h = r.headers.get("set-cookie");
    if (h) cookie = h.split(";")[0];
    const d = (r.headers.get("content-type") || "").includes("json")
      ? await r.json()
      : await r.text();
    assert.equal(
      r.status,
      status,
      `${method} ${route}: ${JSON.stringify(d).slice(0, 500)}`,
    );
    return d;
  };
}
const qb = {
  subject: "math",
  topic: "Arithmetic",
  subtopic: "Percentage",
  text: "What is 12% of 100?",
  options: ["6", "8", "12", "25"],
  answer: 2,
  explanation: "100 × 12/100 = 12.",
  source: "Integration fixture",
};
test(
  "PostgreSQL end-to-end: accounts, exam, scheduling, ownership, all import formats, verified history, and 10k inventory",
  { timeout: 70000 },
  async () => {
    const db = await mkdtemp(join(tmpdir(), "examprep-test-"));
    let p;
    try {
      p = await launch(db);
      const auth = {
          email: "test-admin@example.net",
          password: "not-a-demo-password-123",
          name: "Test user",
        },
        a = client(),
        b = client();
      await a("/auth/register", "POST", auth);
      const unauth = await b("/bootstrap");
      assert.equal(unauth.user, null);
      assert.deepEqual(
        unauth.totals.map((t) => t.count),
        [25, 33],
      );
      const attempt = await a("/exams", "POST", {
        mode: "daily",
        track: "BCS",
        count: 25,
        duration: 15,
        penalty: 0.5,
      });
      assert.equal(attempt.questions.length, 25);
      assert.ok(!("answer" in attempt.questions[0]));
      assert.ok(new Set(attempt.questions.map((q) => q.subject)).size > 1);
      await b("/auth/guest", "POST", {});
      await b(`/exams/${attempt.id}`, "GET", undefined, 404);
      const math = attempt.questions.findIndex((q) => q.subject === "math");
      await a(`/exams/${attempt.id}/answer`, "PUT", {
        position: math,
        choice: 0,
        review: true,
        seconds: 10,
      });
      const result = await a(`/exams/${attempt.id}/submit`, "POST", {});
      assert.equal(result.result.score, -0.5);
      assert.equal(result.result.unanswered, 24);
      assert.equal((await a("/revision")).length, 1);
      assert.equal(
        (await a("/history")).find((t) => t.subtopic === "Percentage").accuracy,
        0,
      );
      const d = "2026-11-19";
      await a("/routine/generate", "POST", { day: d, track: "Both" });
      const sessions = (await a("/activity")).routine;
      assert.equal(new Set(sessions.map((s) => s.subject)).size, 2);
      await a("/routine", "POST", { ...sessions[0], minutes: 50 });
      await a("/routine/generate", "POST", { day: d, track: "Both" }, 409);
      await a("/notes", "POST", {
        title: "Saved note",
        body: "Persist after logout",
      });
      await a("/auth/logout", "POST", {});
      await a("/auth/login", "POST", auth);
      assert.equal((await a("/notes"))[0].title, "Saved note");
      assert.ok(!(await b("/notes")).length);
      await a("/admin/import", "POST", { format: "json", content: "[]" }, 403);
      await stop(p);
      p = await launch(db, auth.email);
      await a("/auth/login", "POST", auth);
      assert.equal((await a("/bootstrap")).user.role, "admin");
      await a("/admin/papers", "POST", {
        id: "fixture",
        name: "Test paper",
        track: "BCS",
        year: 2026,
        source: "Test fixture; never public",
      });
      const historic = { ...qb, kind: "Previous-year", paper_id: "fixture" };
      await a("/admin/import", "POST", {
        format: "json",
        content: JSON.stringify([historic]),
      });
      const question = (await a("/questions?admin=1&kind=Previous-year"))
        .data[0];
      assert.equal(question.status, "Pending review");
      assert.equal(
        (await a("/history")).find((t) => t.subtopic === "Percentage")
          .frequency,
        null,
      );
      await a("/admin/questions/" + question.id, "PATCH", { verified: true });
      assert.equal(
        (await a("/history")).find((t) => t.subtopic === "Percentage")
          .frequency,
        null,
      );
      await a("/admin/papers/fixture", "PUT", { verified: true });
      assert.equal(
        (await a("/history")).find((t) => t.subtopic === "Percentage")
          .frequency,
        1,
      );
      const cols = [
        "subject",
        "topic",
        "subtopic",
        "text",
        "a",
        "b",
        "c",
        "d",
        "answer",
        "explanation",
        "source",
      ];
      const row = [
        qb.subject,
        qb.topic,
        qb.subtopic,
        qb.text,
        ...qb.options,
        "C",
        qb.explanation,
        qb.source,
      ];
      assert.equal(
        (
          await a("/admin/import", "POST", {
            format: "csv",
            content: [cols.join(","), row.join(",")].join("\n"),
            preview: true,
          })
        ).count,
        1,
      );
      const wb = new ExcelJS.Workbook(),
        sheet = wb.addWorksheet("Questions");
      sheet.addRow(cols);
      sheet.addRow(row);
      assert.equal(
        (
          await a("/admin/import", "POST", {
            format: "xlsx",
            content: Buffer.from(await wb.xlsx.writeBuffer()).toString(
              "base64",
            ),
            preview: true,
          })
        ).count,
        1,
      );
      assert.equal((await a("/admin/export/json")).length, 59);
      if (process.env.SCALE_TEST === "1") {
        for (let i = 0; i < 4; i++)
          await a("/admin/import", "POST", {
            format: "json",
            content: JSON.stringify(
              Array.from({ length: 2500 }, (_, j) => ({
                ...qb,
                text: `Capacity fixture ${i * 2500 + j}`,
              })),
            ),
          });
        const result = await a("/questions?admin=1&page=1000");
        assert.equal(result.total, 10059);
        assert.equal(result.data.length, 8);
      }
    } finally {
      await stop(p);
      await rm(db, { recursive: true, force: true });
    }
  },
);
