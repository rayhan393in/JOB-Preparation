import express from "express";
import { PGlite } from "@electric-sql/pglite";
import pg from "pg";
import ExcelJS from "exceljs";
import { Readable } from "node:stream";
import { readFile, mkdir } from "node:fs/promises";
import {
  randomUUID,
  randomBytes,
  createHash,
  scrypt,
  timingSafeEqual,
} from "node:crypto";
import { promisify } from "node:util";
import { syllabus, sample, orgs } from "./content.mjs";
import {
  day,
  grade,
  priority,
  selectExam,
  intervals,
  limitInt,
} from "./logic.mjs";
const crypt = promisify(scrypt),
  sha = (x) => createHash("sha256").update(x).digest("hex");
await mkdir(".runtime", { recursive: true });
const db = process.env.DATABASE_URL
  ? new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 8 })
  : new PGlite(process.env.LOCAL_DB_PATH || ".runtime/examprep");
const run = (s, p = []) => db.query(s, p),
  rows = async (s, p) => (await run(s, p)).rows,
  one = async (s, p) => (await rows(s, p))[0];
const schema = await readFile(new URL("./schema.sql", import.meta.url), "utf8");
if (db.exec) await db.exec(schema);
else await db.query(schema);
await run(
  "insert into exam_categories values ('BCS'),('EEE') on conflict do nothing",
);
for (const o of orgs)
  await run("insert into organizations values ($1) on conflict do nothing", [
    o,
  ]);
for (const s of syllabus) {
  await run(
    "insert into subjects values ($1,$2,$3,$4,$5) on conflict do nothing",
    [s.id, s.track, s.name, s.bn, s.marks],
  );
  for (const [g, items] of Object.entries(s.groups)) {
    await run("insert into topics values ($1,$2) on conflict do nothing", [
      s.id,
      g,
    ]);
    await run(
      "insert into subtopics select $1,$2,unnest($3::text[]) on conflict do nothing",
      [s.id, g, items],
    );
  }
}
const fields = [
  "id",
  "track",
  "subject",
  "topic",
  "subtopic",
  "text",
  "options",
  "answer",
  "explanation",
  "difficulty",
  "kind",
  "source",
  "status",
  "paper_id",
  "tags",
];
const insertQ =
  "insert into questions (" +
  fields.join(",") +
  ") values (" +
  fields.map((_, i) => `$${i + 1}`).join(",") +
  ")";
const values = (q) => fields.map((k) => q[k] ?? (k === "tags" ? [] : null));
for (const q of sample)
  await run(`${insertQ} on conflict do nothing`, values(q));
if (process.env.ADMIN_EMAIL)
  await run(
    "update app_users set role='admin' where email=$1 and role='student'",
    [process.env.ADMIN_EMAIL.toLowerCase()],
  );
const fail = (message, status = 400) =>
  Object.assign(new Error(message), { status });
const text = (x, max = 500) =>
    String(x ?? "")
      .trim()
      .slice(0, max),
  cleanDate = (x) => {
    if (
      !/^\d{4}-\d\d-\d\d$/.test(x ?? "") ||
      isNaN(+new Date(x)) ||
      new Date(x).toISOString().slice(0, 10) !== x
    )
      throw fail("Choose a valid date.");
    return x;
  };
const validTracks = ["BCS", "EEE", "Both"];
const app = express();
app.disable("x-powered-by");
app.use("/api", express.json({ limit: "12mb" }));
app.use("/api", (req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  if (req.method !== "GET" && req.get("X-ExamPrep") !== "1")
    return next(fail("Invalid request.", 403));
  next();
});
const current = async (req) => {
  const cookie = (req.headers.cookie || "").match(
    /(?:^|;\s*)ep_session=([a-f0-9]{64})(?:;|$)/,
  )?.[1];
  return cookie
    ? one(
        "select u.id,u.name,u.email,u.role from sessions s join app_users u on s.user_id=u.id where token_hash=$1 and expires_at>now()",
        [sha(cookie)],
      )
    : null;
};
const cookieOptions = (req) => {
  const secure = req.get("x-forwarded-proto") === "https" || req.secure;
  return {
    httpOnly: true,
    sameSite: secure ? "none" : "lax",
    secure,
    partitioned: secure,
    path: "/",
  };
};
const createSession = async (req, res, user) => {
  const raw = randomBytes(32).toString("hex");
  await run("insert into sessions values ($1,$2,now()+interval '14 days')", [
    sha(raw),
    user.id,
  ]);
  res.cookie("ep_session", raw, { ...cookieOptions(req), maxAge: 14 * 864e5 });
  return user;
};
const loginRequired = async (req, res, next) => {
  req.user = await current(req);
  if (!req.user) throw fail("Start a demo session or sign in first.", 401);
  next();
};
const admin = async (req, res, next) => {
  if ((await current(req))?.role !== "admin")
    throw fail("Administrator access required.", 403);
  next();
};
app.get("/api/bootstrap", async (req, res) => {
  const user = await current(req),
    dbSubjects = await rows("select id,marks from subjects");
  const totals = await rows(
    "select track,count(*)::int as count from questions q where not archived and (status='Verified' or status='Sample') and (kind<>'Previous-year' or exists(select 1 from examination_papers p where p.id=q.paper_id and p.status='Verified')) group by track",
  );
  res.json({
    user,
    syllabus: syllabus.map((s) => ({
      ...s,
      marks: dbSubjects.find((x) => x.id === s.id)?.marks ?? s.marks,
    })),
    orgs,
    totals,
    settings: user
      ? ((
          await one("select settings from user_profiles where user_id=$1", [
            user.id,
          ])
        )?.settings ?? {})
      : {},
  });
});
const authTries = new Map();
function throttle(req, key) {
  const t = Date.now();
  if (authTries.size > 2500)
    for (const [k, v] of authTries) if (v.until < t) authTries.delete(k);
  if (authTries.size > 6000) authTries.clear();
  const k = `${req.ip}:${key}`,
    prev = authTries.get(k),
    slot = prev?.until > t ? prev : { count: 0, until: t + 600000 };
  if (++slot.count > 20)
    throw fail("Too many attempts. Try again in 10 minutes.", 429);
  authTries.set(k, slot);
}
app.post("/api/auth/guest", async (req, res) => {
  const found = await current(req);
  if (found) return res.json(found);
  throttle(req, "guest");
  const user = await one(
    "insert into app_users(id,name,role) values ($1,'Guest learner','guest') returning id,name,email,role",
    [randomUUID()],
  );
  res.json(await createSession(req, res, user));
});
app.post("/api/auth/:mode", async (req, res) => {
  const mode = req.params.mode;
  if (mode === "logout") {
    const token = (req.headers.cookie || "").match(
      /(?:^|;\s*)ep_session=([a-f0-9]{64})/,
    )?.[1];
    if (token)
      await run("delete from sessions where token_hash=$1", [sha(token)]);
    res.clearCookie("ep_session", cookieOptions(req));
    return res.json({ ok: true });
  }
  if (!["register", "login"].includes(mode))
    throw fail("Unknown authentication action.", 404);
  const email = text(req.body.email, 255).toLowerCase(),
    password = req.body.password;
  throttle(req, email);
  if (
    !/^\S+@[^\s@]+\.[^\s@]+$/.test(email) ||
    typeof password !== "string" ||
    password.length < 8 ||
    password.length > 128
  )
    throw fail("Use a valid email and a password of 8–128 characters.");
  let user = await one("select * from app_users where email=$1", [email]);
  if (mode === "register") {
    const name = text(req.body.name, 60);
    if (!name) throw fail("Enter your name.");
    if (user) throw fail("An account already uses this email.", 409);
    const salt = randomBytes(16).toString("hex"),
      hash = (await crypt(password, salt, 64)).toString("hex");
    user = await one(
      "insert into app_users(id,email,password,name) values ($1,$2,$3,$4) on conflict(email) do nothing returning *",
      [randomUUID(), email, `${salt}:${hash}`, name],
    );
    if (!user) throw fail("An account already uses this email.", 409);
  } else {
    const [salt, hash] = (
      user?.password || `${"0".repeat(32)}:${"0".repeat(128)}`
    ).split(":");
    if (
      !timingSafeEqual(
        await crypt(password, salt, 64),
        Buffer.from(hash, "hex"),
      ) ||
      !user
    )
      throw fail("Email or password is incorrect.", 401);
  }
  const { id, name, role } = user;
  res.json(await createSession(req, res, { id, name, email, role }));
});
const visible =
  "not q.archived and q.status in ('Sample','Verified') and (q.kind<>'Previous-year' or p.status='Verified')";
function filtered(input, user, opts = {}) {
  const args = [],
    where = [opts.all ? "not q.archived" : visible],
    add = (sql, val) => {
      args.push(val);
      where.push(sql.replace("?", `$${args.length}`));
    };
  for (const [key, col] of Object.entries({
    track: "q.track",
    subject: "q.subject",
    topic: "q.topic",
    subtopic: "q.subtopic",
    difficulty: "q.difficulty",
    paper: "q.paper_id",
    organization: "p.organization",
    kind: "q.kind",
  }))
    if (input[key] && input[key] !== "Both" && input[key] !== "All")
      add(`${col} = ?`, text(input[key], 180));
  if (input.search)
    add(
      "(q.text ilike ?)",
      `%${text(input.search, 100).replace(/[\\%_]/g, "\\$&")}%`,
    );
  if (opts.book || input.selection === "Bookmarked")
    add(
      "exists(select 1 from bookmarks b where b.question_id=q.id and b.user_id=?)",
      user?.id ?? null,
    );
  if (input.selection === "Original practice")
    where.push("q.kind='Original practice'");
  if (input.selection === "Verified past questions")
    where.push(
      "q.kind='Previous-year' and q.status='Verified' and p.status='Verified'",
    );
  if (input.selection === "Revision due")
    add(
      "exists(select 1 from revision_schedules r where r.question_id=q.id and r.user_id=? and r.due <= (now() at time zone 'Asia/Dhaka')::date)",
      user?.id ?? null,
    );
  if (input.selection === "Incorrect")
    add(
      "exists(select 1 from exam_attempts e cross join lateral jsonb_array_elements(e.questions) with ordinality j(x,i) join attempt_answers a on a.attempt_id=e.id and a.position=j.i-1 where e.user_id=? and e.submitted_at is not null and x->>'id'=q.id and a.choice<>(x->>'answer')::int)",
      user?.id ?? null,
    );
  if (input.selection === "Unattempted")
    add(
      "not exists(select 1 from exam_attempts e, jsonb_array_elements(e.questions) x where e.user_id=? and e.submitted_at is not null and x->>'id'=q.id)",
      user?.id ?? null,
    );
  return { args, where: " where " + where.join(" and ") };
}
const joinQ =
  " from questions q left join examination_papers p on p.id=q.paper_id";
app.get("/api/questions", async (req, res) => {
  const user = await current(req),
    all = req.query.admin === "1" && user?.role === "admin",
    { where, args } = filtered(req.query, user, {
      all,
      book: req.query.book === "1",
    }),
    page = limitInt(req.query.page, 1, 50000, 1),
    offset = (page - 1) * 8;
  const data = await rows(
      `select q.*,p.name as paper_name,p.year,p.organization${joinQ}${where} order by q.id limit 8 offset ${offset}`,
      args,
    ),
    n = await one(`select count(*)::int as count${joinQ}${where}`, args);
  res.json({ data, total: n.count, page });
});
app.get("/api/papers", async (req, res) => {
  const user = await current(req);
  res.json(
    await rows(
      `select p.*, count(q.id)::int as questions from examination_papers p left join questions q on q.paper_id=p.id and not q.archived ${user?.role === "admin" && req.query.admin === "1" ? "" : "and q.status='Verified' where p.status='Verified'"} group by p.id order by p.year desc,p.name`,
    ),
  );
});
app.post("/api/bookmarks/:id", loginRequired, async (req, res) => {
  if (req.body.saved)
    await run("insert into bookmarks values ($1,$2) on conflict do nothing", [
      req.user.id,
      req.params.id,
    ]);
  else
    await run("delete from bookmarks where user_id=$1 and question_id=$2", [
      req.user.id,
      req.params.id,
    ]);
  res.json({ ok: true });
});
app.get("/api/bookmarks", loginRequired, async (req, res) =>
  res.json(
    (
      await rows("select question_id from bookmarks where user_id=$1", [
        req.user.id,
      ])
    ).map((x) => x.question_id),
  ),
);
app.post("/api/report/:id", loginRequired, async (req, res) => {
  const reason = text(req.body.reason, 2000);
  if (!reason) throw fail("Enter a reason.");
  await run(
    "insert into question_reports(id,user_id,question_id,reason) values ($1,$2,$3,$4)",
    [randomUUID(), req.user.id, req.params.id, reason],
  );
  res.json({ ok: true });
});
app.get("/api/notes", loginRequired, async (req, res) =>
  res.json(
    await rows(
      "select id,title,body,updated_at from notes where user_id=$1 order by updated_at desc",
      [req.user.id],
    ),
  ),
);
app.post("/api/notes", loginRequired, async (req, res) => {
  const title = text(req.body.title, 150),
    body = text(req.body.body, 30000),
    id = req.body.id;
  if (!title || !body) throw fail("A title and note are required.");
  const result = id
    ? await one(
        "update notes set title=$1,body=$2,updated_at=now() where user_id=$3 and id=$4 returning id",
        [title, body, req.user.id, id],
      )
    : await one(
        "insert into notes(id,user_id,title,body) values ($1,$2,$3,$4) returning id",
        [randomUUID(), req.user.id, title, body],
      );
  if (!result) throw fail("Note not found.", 404);
  res.json(result);
});
app.delete("/api/notes/:id", loginRequired, async (req, res) => {
  await run("delete from notes where user_id=$1 and id=$2", [
    req.user.id,
    req.params.id,
  ]);
  res.json({ ok: true });
});
app.put("/api/settings", loginRequired, async (req, res) => {
  const { track, weights, minutes, subjects, restDays, target, thresholds } =
    req.body;
  if (track && !validTracks.includes(track))
    throw fail("Invalid preparation track.");
  if (
    weights &&
    (!Array.isArray(weights) ||
      weights.length !== 4 ||
      weights.some((x) => !Number.isFinite(x) || x < 0) ||
      weights.reduce((a, b) => a + b, 0) !== 100)
  )
    throw fail("Priority weights must be nonnegative and total 100.");
  if (
    thresholds &&
    (!Array.isArray(thresholds) ||
      thresholds.length !== 3 ||
      thresholds.some(
        (x, i) =>
          !Number.isInteger(x) ||
          x < 0 ||
          x > 100 ||
          (i > 0 && x >= thresholds[i - 1]),
      ))
  )
    throw fail("Weakness thresholds must descend from Strong to Moderate.");
  if (target) cleanDate(target);
  const s = {
    track: track || "Both",
    weights: weights || [35, 25, 20, 20],
    minutes: limitInt(minutes, 10, 720, 90),
    subjects: limitInt(subjects, 2, 8, 2),
    restDays: Array.isArray(restDays)
      ? restDays.filter((x) => Number.isInteger(x) && x >= 0 && x <= 6)
      : [],
    target: target || "",
    thresholds: thresholds || [85, 70, 50],
  };
  await run(
    "insert into user_profiles values ($1,$2) on conflict(user_id) do update set settings=excluded.settings",
    [req.user.id, JSON.stringify(s)],
  );
  res.json(s);
});
const settings = async (id) =>
  (await one("select settings from user_profiles where user_id=$1", [id]))
    ?.settings ?? {};
const getAnswers = async (id) =>
  Object.fromEntries(
    (
      await rows(
        "select position,choice,review,seconds from attempt_answers where attempt_id=$1",
        [id],
      )
    ).map((x) => [x.position, x]),
  );
const owned = async (id, owner) => {
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw fail("Exam not found.", 404);
  const attempt = await one(
    "select * from exam_attempts where id=$1 and user_id=$2",
    [id, owner],
  );
  if (!attempt) throw fail("Exam not found.", 404);
  return attempt;
};
async function submit(a) {
  const updated = await one(
    "update exam_attempts set submitted_at=least(now(),ends_at) where id=$1 and submitted_at is null returning submitted_at",
    [a.id],
  );
  if (!updated)
    return {
      ...a,
      submitted_at: (
        await one("select submitted_at from exam_attempts where id=$1", [a.id])
      ).submitted_at,
    };
  a = { ...a, submitted_at: updated.submitted_at };
  const result = grade(a.questions, await getAnswers(a.id), a.penalty),
    today = day(new Date(a.submitted_at));
  for (const q of result.rows) {
    if (q.outcome === "Incorrect")
      await run(
        "insert into revision_schedules values ($1,$2,0,$3::date+1) on conflict(user_id,question_id) do update set step=0,due=excluded.due",
        [a.user_id, q.id, today],
      );
    else if (q.outcome === "Correct")
      await run(
        "update revision_schedules set due=$3::date+($4::int[])[least(step+2,5)],step=least(step+1,4) where user_id=$1 and question_id=$2",
        [a.user_id, q.id, today, intervals],
      );
  }
  return a;
}
const pack = async (a) => {
  const answers = await getAnswers(a.id);
  const { id, mode, track, started_at, ends_at, submitted_at, penalty } = a;
  return {
    id,
    mode,
    track,
    started_at,
    ends_at,
    submitted_at,
    penalty,
    answers,
    questions: a.questions.map(({ answer, explanation, ...q }) => q),
    result: submitted_at ? grade(a.questions, answers, penalty) : null,
  };
};
app.post("/api/exams", loginRequired, async (req, res) => {
  const input = req.body,
    { mode, track } = input;
  if (
    !["daily", "manual", "mock", "past"].includes(mode) ||
    !validTracks.includes(track)
  )
    throw fail("Choose a valid exam type and track.");
  if (mode === "past" && !input.paper) throw fail("Choose a verified paper.");
  const count = limitInt(
    input.count,
    mode === "daily" ? 2 : 1,
    200,
    track === "EEE" ? 30 : 25,
  );
  const duration =
    mode === "mock" && track === "BCS"
      ? 120
      : limitInt(input.duration, 1, 240, track === "EEE" ? 20 : 15);
  const penalty = Number(input.penalty ?? (track === "BCS" ? 0.5 : 0));
  if (!Number.isFinite(penalty) || penalty < 0 || penalty > 1)
    throw fail("Negative marking must be between 0 and 1.");
  const { where, args } = filtered(
    mode === "past"
      ? { paper: input.paper, selection: "Verified past questions" }
      : mode === "mock" && track === "BCS"
        ? { track }
        : input,
    req.user,
  );
  let sql = where;
  if (
    Array.isArray(input.subjects) &&
    input.subjects.length &&
    !(mode === "mock" && track === "BCS") &&
    mode !== "past"
  ) {
    args.push(input.subjects);
    sql += ` and q.subject=any($${args.length}::text[])`;
  }
  const distribution = input.distribution ?? [40, 25, 15, 10, 10];
  if (
    mode === "daily" &&
    (!Array.isArray(distribution) ||
      distribution.length !== 5 ||
      distribution.some((x) => !Number.isFinite(x) || x < 0) ||
      distribution.reduce((a, b) => a + b, 0) !== 100)
  )
    throw fail(
      "The daily question mix must contain nonnegative weights totaling 100.",
    );
  let order = "random()",
    extra = "";
  if (mode === "daily") {
    args.push(req.user.id);
    const u = `$${args.length}`;
    extra = ` ,exists(select 1 from revision_schedules r where r.question_id=q.id and r.user_id=${u} and r.due<=(now() at time zone 'Asia/Dhaka')::date) as due_now`;
    order = `(case when exists(select 1 from routine_sessions r where r.user_id=${u} and r.day=(now() at time zone 'Asia/Dhaka')::date and r.subject=q.subject and r.subtopic=q.subtopic) then 2 else 0 end + case when exists(select 1 from revision_schedules r where r.question_id=q.id and r.user_id=${u} and r.due<=(now() at time zone 'Asia/Dhaka')::date) then 1 else 0 end - case when exists(select 1 from exam_attempts e, jsonb_array_elements(e.questions) x where e.user_id=${u} and e.submitted_at>=now()-interval '3 days' and x->>'id'=q.id) then 1 else 0 end + random()*2) desc`;
  }
  const data = await rows(
    `select q.id,q.track,q.subject,q.topic,q.subtopic,q.text,q.options,q.answer,q.explanation,q.difficulty,q.kind,q.status${extra}${joinQ}${sql} order by ${order} limit ${mode === "mock" && track === "BCS" ? 100000 : mode === "daily" ? 2000 : 201}`,
    args,
  );
  if (mode === "daily") {
    const opts = await settings(req.user.id);
    const ranks = new Map(
      (await history(req.user.id, opts.weights || [35, 25, 20, 20])).map(
        (t) => [JSON.stringify([t.subject, t.topic, t.subtopic]), t],
      ),
    );
    for (const q of data) {
      const rank = ranks.get(JSON.stringify([q.subject, q.topic, q.subtopic]));
      q.buckets = [
        rank?.score >= 65
          ? "High priority"
          : rank?.score >= 40
            ? "Medium priority"
            : null,
        q.due_now ? "Revision" : null,
        rank?.accuracy != null && rank.accuracy < (opts.thresholds?.[2] ?? 50)
          ? "Weak topics"
          : null,
        q.kind === "Previous-year" ? "Previous-year" : null,
      ].filter(Boolean);
      delete q.due_now;
    }
  }
  let selected;
  try {
    selected =
      mode === "past"
        ? data.length && data.length <= 200
          ? data
          : (() => {
              throw Error(
                "The selected paper must contain 1–200 verified questions.",
              );
            })()
        : selectExam(data, {
            count,
            mode,
            track,
            distribution: mode === "daily" ? distribution : null,
            subjects: await rows(
              "select id,name,marks from subjects where track='BCS' order by id",
            ),
          });
  } catch (e) {
    throw fail(e.message);
  }
  const id = randomUUID();
  const a = await one(
    "insert into exam_attempts(id,user_id,mode,track,ends_at,penalty,questions) values ($1,$2,$3,$4,now()+$5::int*interval '1 minute',$6,$7) returning *",
    [
      id,
      req.user.id,
      mode,
      track,
      duration,
      penalty,
      JSON.stringify(selected.map(({ buckets, ...q }) => q)),
    ],
  );
  res.json(await pack(a));
});
app.get("/api/exams/:id", loginRequired, async (req, res) => {
  let a = await owned(req.params.id, req.user.id);
  if (!a.submitted_at && new Date(a.ends_at) <= new Date()) a = await submit(a);
  res.json(await pack(a));
});
app.put("/api/exams/:id/answer", loginRequired, async (req, res) => {
  const a = await owned(req.params.id, req.user.id),
    { position, choice, review, seconds } = req.body;
  if (
    !Number.isInteger(position) ||
    position < 0 ||
    position >= a.questions.length ||
    !(
      choice === null ||
      (Number.isInteger(choice) && choice >= 0 && choice <= 3)
    )
  )
    throw fail("Invalid answer.");
  const saved = await one(
    "with permitted as (select id from exam_attempts where id=$1 and submitted_at is null and ends_at>now() for update) insert into attempt_answers select id,$2,$3,$4,$5 from permitted on conflict(attempt_id,position) do update set choice=excluded.choice,review=excluded.review,seconds=greatest(attempt_answers.seconds,excluded.seconds) returning position",
    [a.id, position, choice, !!review, limitInt(seconds, 0, 14400, 0)],
  );
  if (!saved) throw fail("The examination is closed.", 409);
  res.json(saved);
});
app.post("/api/exams/:id/submit", loginRequired, async (req, res) =>
  res.json(await pack(await submit(await owned(req.params.id, req.user.id)))),
);
app.get("/api/activity", loginRequired, async (req, res) => {
  const data = await rows(
    "select id,mode,track,started_at,submitted_at,ends_at,penalty,questions from exam_attempts where user_id=$1 order by started_at desc limit 500",
    [req.user.id],
  );
  const answerRows = data.length
    ? await rows(
        "select * from attempt_answers where attempt_id=any($1::uuid[])",
        [data.map((e) => e.id)],
      )
    : [];
  const answers = Map.groupBy
    ? Map.groupBy(answerRows, (a) => a.attempt_id)
    : answerRows.reduce(
        (m, a) => m.set(a.attempt_id, [...(m.get(a.attempt_id) || []), a]),
        new Map(),
      );
  const exams = data.map(({ questions, ...e }) => {
    if (!e.submitted_at) return e;
    const g = grade(
      questions,
      Object.fromEntries((answers.get(e.id) || []).map((a) => [a.position, a])),
      e.penalty,
    );
    return {
      ...e,
      score: g.score,
      accuracy: g.accuracy,
      correct: g.correct,
      incorrect: g.incorrect,
      unanswered: g.unanswered,
      total: questions.length,
      topics: g.rows.map(
        ({ id, subject, subtopic, track, outcome, seconds }) => ({
          id,
          subject,
          subtopic,
          track,
          outcome,
          seconds,
        }),
      ),
    };
  });
  const routine = await rows(
    "select id,day::text,subject,topic,subtopic,minutes,completed,position,manual from routine_sessions where user_id=$1 order by day,position",
    [req.user.id],
  );
  res.json({ exams, routine });
});
app.get("/api/revision", loginRequired, async (req, res) =>
  res.json(
    await rows(
      "select r.question_id,r.step,r.due::text,q.text,q.subject,q.subtopic,q.explanation,q.options,q.answer from revision_schedules r join questions q on q.id=r.question_id where r.user_id=$1 and not q.archived order by r.due limit 500",
      [req.user.id],
    ),
  ),
);
const history = async (id, weights) => {
  const items = await rows(
    "select q.subject,q.topic,q.subtopic,q.text,p.id as paper_id,p.name as paper,p.year from questions q join examination_papers p on p.id=q.paper_id where q.kind='Previous-year' and q.status='Verified' and p.status='Verified' and not q.archived",
  );
  const practice = id
    ? await rows(
        "select q->>'subject' as subject,q->>'topic' as topic,q->>'subtopic' as subtopic,count(*)::int attempts,count(*) filter (where a.choice=(q->>'answer')::int)::int correct from exam_attempts e cross join lateral jsonb_array_elements(e.questions) with ordinality j(q,i) join attempt_answers a on a.attempt_id=e.id and a.position=j.i-1 where e.user_id=$1 and e.submitted_at is not null and a.choice is not null group by 1,2,3",
        [id],
      )
    : [];
  const marks = Object.fromEntries(
    (await rows("select id,marks from subjects")).map((s) => [s.id, s.marks]),
  );
  return syllabus.flatMap((s) => {
    const trackItems = items.filter(
        (x) => syllabus.find((k) => k.id === x.subject)?.track === s.track,
      ),
      maxYear = trackItems.reduce((y, x) => Math.max(y, x.year), 0),
      recent = trackItems.filter((x) => x.year >= maxYear - 2);
    return Object.entries(s.groups).flatMap(([topic, subtopics]) =>
      subtopics.map((subtopic) => {
        const match = (x) =>
            x.subject === s.id && x.topic === topic && x.subtopic === subtopic,
          hit = trackItems.filter(match),
          p = practice.find(match),
          f = trackItems.length ? (100 * hit.length) / trackItems.length : null,
          r = recent.length
            ? (100 * recent.filter(match).length) / recent.length
            : null,
          accuracy = p ? (100 * p.correct) / p.attempts : null;
        return {
          track: s.track,
          subject: s.id,
          topic,
          subtopic,
          frequency: trackItems.length ? hit.length : null,
          percentage: f === null ? null : Math.round(f * 100) / 100,
          appeared: [...new Set(hit.map((x) => x.paper))],
          repeated:
            hit.length -
            new Set(hit.map((x) => x.text.trim().toLowerCase())).size,
          last: hit.length ? Math.max(...hit.map((x) => x.year)) : null,
          accuracy,
          score: priority(
            [
              f,
              r,
              s.track === "BCS"
                ? Math.min(100, (marks[s.id] / 35) * 100)
                : null,
              accuracy === null ? null : 100 - accuracy,
            ],
            weights,
          ),
          estimated: f === null,
        };
      }),
    );
  });
};
app.get("/api/history", async (req, res) => {
  const u = await current(req),
    s = u ? await settings(u.id) : {};
  res.json(await history(u?.id, s.weights || [35, 25, 20, 20]));
});
app.post("/api/routine/generate", loginRequired, async (req, res) => {
  const d = cleanDate(req.body.day),
    s = await settings(req.user.id),
    track = validTracks.includes(req.body.track)
      ? req.body.track
      : s.track || "Both";
  if (s.restDays?.includes(new Date(d + "T12:00:00Z").getUTCDay()))
    throw fail("This date is a configured rest day.");
  if (s.target && d > s.target)
    throw fail("This date is after your target exam date.");
  const exists = await one(
    "select bool_or(manual) edited from routine_sessions where user_id=$1 and day=$2",
    [req.user.id, d],
  );
  if (exists.edited && !req.body.confirm)
    throw fail(
      "This routine has manual edits. Confirm before replacing it.",
      409,
    );
  const available = await history(req.user.id, s.weights || [35, 25, 20, 20]);
  const due = await rows(
    "select q.subject,q.subtopic from revision_schedules r join questions q on q.id=r.question_id where r.user_id=$1 and r.due<=$2",
    [req.user.id, d],
  );
  const prior = await rows(
    "select subject,subtopic,completed from routine_sessions where user_id=$1 and day<$2 order by day desc limit 100",
    [req.user.id, d],
  );
  const pool = available
    .filter((x) => track === "Both" || track === x.track)
    .map((x, i) => ({
      ...x,
      rank:
        (x.score ?? 35) +
        35 *
          Number(
            due.some(
              (r) => r.subject === x.subject && r.subtopic === x.subtopic,
            ),
          ) +
        12 *
          Number(
            prior.some(
              (r) =>
                !r.completed &&
                r.subject === x.subject &&
                r.subtopic === x.subtopic,
            ),
          ) -
        40 *
          Number(
            prior.some(
              (r) =>
                r.completed &&
                r.subject === x.subject &&
                r.subtopic === x.subtopic,
            ),
          ) +
        ((new Date(d).getUTCDate() * 13 + i * 19) % 31),
    }))
    .sort((a, b) => b.rank - a.rank);
  const picks = [];
  if (track === "Both")
    for (const t of ["BCS", "EEE"]) picks.push(pool.find((x) => x.track === t));
  const total = s.minutes || 90,
    n = Math.min(s.subjects || 2, Math.floor(total / 5));
  for (const q of pool)
    if (picks.length < n && !picks.some((x) => x.subject === q.subject))
      picks.push(q);
  await run("delete from routine_sessions where user_id=$1 and day=$2", [
    req.user.id,
    d,
  ]);
  for (const [i, q] of picks.entries())
    await run(
      "insert into routine_sessions(id,user_id,day,subject,topic,subtopic,minutes,position) values ($1,$2,$3,$4,$5,$6,$7,$8)",
      [
        randomUUID(),
        req.user.id,
        d,
        q.subject,
        q.topic,
        q.subtopic,
        Math.min(
          360,
          Math.floor(total / picks.length) + (i < total % picks.length ? 1 : 0),
        ),
        i,
      ],
    );
  res.json({ ok: true });
});
app.post("/api/routine", loginRequired, async (req, res) => {
  const { id, subject, topic, subtopic, completed } = req.body,
    d = cleanDate(req.body.day),
    minutes = limitInt(req.body.minutes, 5, 360, 0),
    p = limitInt(req.body.position, 0, 500, 0);
  const topicName =
    topic ||
    Object.entries(syllabus.find((x) => x.id === subject)?.groups || {}).find(
      ([, subs]) => subs.includes(subtopic),
    )?.[0];
  if (
    !minutes ||
    !syllabus
      .find((x) => x.id === subject)
      ?.groups[topicName]?.includes(subtopic)
  )
    throw fail("Choose a syllabus topic and a duration of 5–360 minutes.");
  if (id) {
    const r = await one(
      "update routine_sessions set day=$3,subject=$4,topic=$5,subtopic=$6,minutes=$7,position=$8,completed=$9,manual=true where id=$1 and user_id=$2 returning id",
      [
        id,
        req.user.id,
        d,
        subject,
        topicName,
        subtopic,
        minutes,
        p,
        !!completed,
      ],
    );
    if (!r) throw fail("Session not found.", 404);
  } else
    await run(
      "insert into routine_sessions values ($1,$2,$3,$4,$5,$6,$7,$8,$9,true)",
      [
        randomUUID(),
        req.user.id,
        d,
        subject,
        topicName,
        subtopic,
        minutes,
        !!completed,
        p,
      ],
    );
  res.json({ ok: true });
});
app.delete("/api/routine/:id", loginRequired, async (req, res) => {
  await run("delete from routine_sessions where id=$1 and user_id=$2", [
    req.params.id,
    req.user.id,
  ]);
  res.json({ ok: true });
});
function normalize(input) {
  const subject = text(input.subject),
    s = syllabus.find((x) => x.id === subject),
    subtopic = text(input.subtopic),
    topic =
      text(input.topic) ||
      Object.keys(s?.groups ?? {}).find((k) => s.groups[k].includes(subtopic));
  const options = (
    Array.isArray(input.options)
      ? input.options
      : [input.a, input.b, input.c, input.d]
  ).map((x) => text(x, 2000));
  const answer =
    typeof input.answer === "number"
      ? input.answer
      : /^[A-D]$/i.test(input.answer ?? "")
        ? "ABCD".indexOf(input.answer.toUpperCase())
        : -1;
  const q = {
    track: s?.track,
    subject,
    topic,
    subtopic,
    text: text(input.text, 5000),
    options,
    answer,
    explanation: text(input.explanation, 10000),
    difficulty: text(input.difficulty) || "Easy",
    kind: text(input.kind) || "Original practice",
    source: text(input.source, 1000),
    paper_id: text(input.paper_id) || null,
    tags: (Array.isArray(input.tags)
      ? input.tags
      : String(input.tags || "").split(";")
    )
      .map((x) => text(x, 60))
      .filter(Boolean)
      .slice(0, 30),
  };
  if (
    !s?.groups[topic]?.includes(subtopic) ||
    !q.text ||
    !q.source ||
    !q.explanation ||
    options.length !== 4 ||
    options.some((x) => !x) ||
    new Set(options.map((x) => x.toLowerCase())).size !== 4 ||
    !Number.isInteger(answer) ||
    answer < 0 ||
    answer > 3 ||
    !["Easy", "Medium", "Hard"].includes(q.difficulty) ||
    ![
      "Original practice",
      "AI-generated",
      "User-created",
      "Previous-year",
    ].includes(q.kind) ||
    (q.kind === "Previous-year" && !q.paper_id)
  )
    throw fail(
      "Provide a valid subject, subtopic, question, four distinct options, answer A–D, source and explanation. Previous-year questions require a paper ID.",
    );
  return q;
}
async function validatePaper(q) {
  if (
    q.paper_id &&
    !(await one("select 1 from examination_papers where id=$1 and track=$2", [
      q.paper_id,
      q.track,
    ]))
  )
    throw fail("The paper ID must exist and match the question track.");
}
app.post("/api/admin/papers", admin, async (req, res) => {
  const { track, year, organization } = req.body,
    id = text(req.body.id, 80),
    name = text(req.body.name, 150),
    source = text(req.body.source, 1000);
  if (
    !id ||
    !name ||
    !source ||
    !["BCS", "EEE"].includes(track) ||
    !limitInt(year, 1900, 2200, 0) ||
    (organization && !orgs.includes(organization))
  )
    throw fail(
      "A paper requires a valid ID, exam name, track, year, and source.",
    );
  await run(
    "insert into examination_papers(id,track,name,year,organization,source) values ($1,$2,$3,$4,$5,$6)",
    [id, track, name, Number(year), organization || null, source],
  );
  res.json({ ok: true });
});
app.put("/api/admin/papers/:id", admin, async (req, res) => {
  await run("update examination_papers set status=$2 where id=$1", [
    req.params.id,
    req.body.verified ? "Verified" : "Pending review",
  ]);
  res.json({ ok: true });
});
app.put("/api/admin/marks", admin, async (req, res) => {
  const b = syllabus.filter((x) => x.track === "BCS"),
    m = b.map((x) => Number(req.body[x.id]));
  if (
    m.some((x) => !Number.isInteger(x) || x < 0) ||
    m.reduce((a, b) => a + b, 0) !== 200
  )
    throw fail("Marks must be nonnegative integers that total 200.");
  await run(
    "update subjects s set marks=v.marks from unnest($1::text[],$2::int[]) v(id,marks) where s.id=v.id",
    [b.map((x) => x.id), m],
  );
  res.json({ ok: true });
});
app.post("/api/admin/questions", admin, async (req, res) => {
  const input = req.body,
    q = normalize(input);
  await validatePaper(q);
  const u = await current(req);
  const id = text(input.id, 100) || randomUUID();
  if (input.id) {
    const prev = await one("select * from questions where id=$1", [id]);
    if (!prev) throw fail("Question not found.", 404);
    await run(
      "insert into question_revisions(question_id,changed_by,snapshot) values ($1,$2,$3)",
      [id, u.id, JSON.stringify(prev)],
    );
    await run(
      `update questions set ${fields
        .slice(1)
        .map((k, i) => `${k}=$${i + 2}`)
        .join(",")} where id=$1`,
      values({ ...q, id, status: "Pending review" }),
    );
  } else await run(insertQ, values({ ...q, id, status: "Pending review" }));
  res.json({ id });
});
app.get("/api/admin/questions/:id", admin, async (req, res) => {
  const q = await one("select * from questions where id=$1", [req.params.id]);
  if (!q) throw fail("Question not found.", 404);
  res.json(q);
});
app.get("/api/admin/questions/:id/history", admin, async (req, res) =>
  res.json(
    await rows(
      "select id,created_at,snapshot from question_revisions where question_id=$1 order by id desc",
      [req.params.id],
    ),
  ),
);
app.patch("/api/admin/questions/:id", admin, async (req, res) => {
  const u = await current(req);
  const replaced = await one(
    `with old as (select * from questions where id=$1 for update), history as (insert into question_revisions(question_id,changed_by,snapshot) select id,$4,to_jsonb(old) from old) update questions q set status=case when $2::boolean then 'Verified' else 'Pending review' end, archived=$3::boolean from old where q.id=old.id returning q.id`,
    [req.params.id, !!req.body.verified, !!req.body.archived, u.id],
  );
  if (!replaced) throw fail("Question not found.", 404);
  res.json({ ok: true });
});
app.get("/api/admin/reports", admin, async (req, res) =>
  res.json(
    await rows(
      "select r.id,r.reason,r.created_at,q.text from question_reports r join questions q on q.id=r.question_id order by r.created_at desc limit 200",
    ),
  ),
);
const columns = [
  "subject",
  "topic",
  "subtopic",
  "text",
  "a",
  "b",
  "c",
  "d",
  "answer",
  "explanation",
  "difficulty",
  "kind",
  "source",
  "paper_id",
  "tags",
];
app.post("/api/admin/import", admin, async (req, res) => {
  const { format, content } = req.body;
  let data;
  try {
    if (format === "json") data = JSON.parse(content);
    else {
      const w = new ExcelJS.Workbook();
      const sheet =
        format === "csv"
          ? await w.csv.read(Readable.from([content]), {
              parserOptions: { ignoreEmpty: true },
            })
          : format === "xlsx"
            ? (await w.xlsx.load(Buffer.from(content, "base64"))).worksheets[0]
            : null;
      if (!sheet) throw Error();
      const key = (sheet.getRow(1).values || []).map((x) =>
        String(x)
          .replace(/^\uFEFF/, "")
          .trim()
          .toLowerCase(),
      );
      data = [];
      sheet.eachRow((r, n) => {
        if (n > 1)
          data.push(
            Object.fromEntries(
              key
                .slice(1)
                .filter(Boolean)
                .map((k) => [k, r.getCell(key.indexOf(k)).text]),
            ),
          );
      });
    }
  } catch {
    throw fail("Could not parse this file. Use the supplied template headers.");
  }
  if (!Array.isArray(data) || !data.length || data.length > 2500)
    throw fail("Import 1–2,500 questions per batch.");
  const validated = [],
    errors = [];
  const papers = await rows("select id,track from examination_papers");
  for (const [i, raw] of data.entries()) {
    try {
      const q = normalize(raw);
      if (
        q.paper_id &&
        !papers.some((p) => p.id === q.paper_id && p.track === q.track)
      )
        throw Error("Paper ID must match a registered paper and track.");
      validated.push({ ...q, id: randomUUID(), status: "Pending review" });
    } catch (e) {
      errors.push(`Row ${i + 1}: ${e.message}`);
    }
  }
  if (errors.length)
    return res
      .status(400)
      .json({
        error: `${errors.length} row(s) failed validation. No questions were added. ${errors.slice(0, 6).join(" ")}`,
      });
  if (req.body.preview)
    return res.json({
      count: validated.length,
      preview: validated.slice(0, 5),
    });
  await run(
    `insert into questions (${fields.join(",")}) select ${fields.join(",")} from jsonb_to_recordset($1::jsonb) as x(id text,track text,subject text,topic text,subtopic text,text text,options text[],answer int,explanation text,difficulty text,kind text,source text,status text,paper_id text,tags text[])`,
    [JSON.stringify(validated)],
  );
  res.json({ count: validated.length });
});
app.get("/api/admin/export/:format", admin, async (req, res) => {
  const data = await rows(
    "select * from questions where not archived order by id limit 100000",
  );
  const format = req.params.format;
  const mapped = data.map((q) => ({
    ...q,
    a: q.options[0],
    b: q.options[1],
    c: q.options[2],
    d: q.options[3],
    answer: "ABCD"[q.answer],
    tags: q.tags.join(";"),
  }));
  if (format === "json")
    return res.attachment("examprep-questions.json").json(mapped);
  if (!["xlsx", "csv"].includes(format)) throw fail("Unsupported format.");
  const wb = new ExcelJS.Workbook(),
    sheet = wb.addWorksheet("Questions");
  sheet.addRow(columns);
  for (const q of mapped)
    sheet.addRow(
      columns.map((k) => {
        const v = q[k] ?? "";
        return format === "csv" && /^[=+\-@\t\r\n]/.test(String(v))
          ? "'" + v
          : v;
      }),
    );
  res.attachment(`examprep-questions.${format}`);
  if (format === "csv") await wb.csv.write(res);
  else await wb.xlsx.write(res);
  res.end();
});
app.use("/api", (req, res) =>
  res.status(404).json({ error: "Endpoint not found." }),
);
if (process.argv.includes("--dev")) {
  const { createServer } = await import("vite");
  const vite = await createServer({
    server: { middlewareMode: true, allowedHosts: true },
    appType: "spa",
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static("dist"));
  app.get(/.*/, (req, res) => res.sendFile("index.html", { root: "dist" }));
}
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  if (!err.status && !["23505", "23503", "22P02"].includes(err.code))
    console.error(err);
  res
    .status(
      err.status ||
        (["23505", "23503", "22P02"].includes(err.code) ? 400 : 500),
    )
    .json({
      error: err.status
        ? err.message
        : err.code === "23505"
          ? "This record already exists."
          : ["23503", "22P02"].includes(err.code)
            ? "Invalid or unknown record."
            : "Something went wrong. Please try again.",
    });
});
const listener = app.listen(process.env.PORT || 5173, "0.0.0.0", () =>
  console.log(`ExamPrep BD is ready on port ${listener.address().port}.`),
);
