export const orgs = [
  "BPDB",
  "DESCO",
  "DPDC",
  "BREB",
  "PGCB",
  "NESCO",
  "WZPDCL",
  "EGCB",
  "APSCL",
  "Petrobangla",
  "Other Government Jobs",
  "Private Sector Engineering Jobs",
];
const groups = (s) =>
  Object.fromEntries(
    s.split(";").map((g) => {
      const [title, items] = g.split(":");
      return [title, items.split("|")];
    }),
  );
const C = (track, id, name, bn, marks, g) => ({
  track,
  id,
  name,
  bn,
  marks,
  groups: groups(g),
});
export const syllabus = [
  C(
    "BCS",
    "bangla",
    "Bangla",
    "বাংলা",
    35,
    "Grammar:ভাষা ও বাংলা ভাষারীতি|ধ্বনি ও বর্ণ|সন্ধি|সমাস|কারক ও বিভক্তি|প্রকৃতি ও প্রত্যয়|উপসর্গ|অনুসর্গ|পদ প্রকরণ|বাক্য|বাক্য পরিবর্তন|শুদ্ধ বানান|শুদ্ধ প্রয়োগ|বাগধারা|এক কথায় প্রকাশ|সমার্থক শব্দ|বিপরীত শব্দ|পারিভাষিক শব্দ|প্রবাদ-প্রবচন;Literature:প্রাচীন যুগ|মধ্যযুগ|আধুনিক যুগ|কবি ও সাহিত্যিক|বিখ্যাত সাহিত্যকর্ম|সাহিত্য আন্দোলন|পত্র-পত্রিকা|ভাষা আন্দোলনভিত্তিক সাহিত্য|মুক্তিযুদ্ধভিত্তিক সাহিত্য",
  ),
  C(
    "BCS",
    "english",
    "English",
    "ইংরেজি",
    35,
    "Grammar:Parts of Speech|Noun|Pronoun|Adjective|Verb|Adverb|Preposition|Conjunction|Article|Tense|Right Form of Verbs|Subject-Verb Agreement|Voice|Narration|Transformation|Conditional Sentences|Clauses|Phrases|Correction|Sentence Completion|Appropriate Prepositions|Synonyms|Antonyms|Idioms and Phrases|One Word Substitution|Spelling;Literature:Shakespeare|Romantic Period|Victorian Period|Modern Period|Famous Authors|Famous Books|Literary Terms|Literary Movements|Characters and Quotations",
  ),
  C(
    "BCS",
    "bangladesh",
    "Bangladesh Affairs",
    "বাংলাদেশ বিষয়াবলি",
    30,
    "History:Ancient Bengal|British Rule|Pakistan Period|Language Movement|Liberation War 1971;Governance:Constitution|Constitutional Amendments|Government Structure|Parliament|Judiciary|Administration|National Institutions;Society and Economy:Economy|Agriculture|Industry|Natural Resources|Population|Education|Health|National Awards|Current Affairs",
  ),
  C(
    "BCS",
    "international",
    "International Affairs",
    "আন্তর্জাতিক বিষয়াবলি",
    20,
    "Organizations:United Nations|World Bank|IMF|WTO|SAARC|ASEAN|OIC|EU|NATO;World Affairs:International Treaties|Geopolitics|International Relations|Countries and Capitals|Currencies|Wars and Conflicts|International Summits|Current Affairs",
  ),
  C(
    "BCS",
    "geography",
    "Geography, Environment and Disaster Management",
    "ভূগোল, পরিবেশ ও দুর্যোগ ব্যবস্থাপনা",
    10,
    "Geography:Bangladesh Geography|World Geography|Physical Geography|Rivers|Mountains|Climate;Environment and Disasters:Natural Disasters|Cyclones|Floods|Earthquakes|Environmental Pollution|Biodiversity|Climate Change|Sustainable Development",
  ),
  C(
    "BCS",
    "science",
    "General Science",
    "সাধারণ বিজ্ঞান",
    15,
    "Physical Science:Physics|Chemistry|Electricity|Magnetism|Energy;Life Science:Biology|Human Body|Diseases|Nutrition|Genetics;Applied Science:Modern Science|Scientific Discoveries|Everyday Science",
  ),
  C(
    "BCS",
    "ict",
    "Computer and ICT",
    "কম্পিউটার ও তথ্যপ্রযুক্তি",
    15,
    "Fundamentals:Computer Fundamentals|Hardware|Software|Operating Systems|Number Systems|Binary Arithmetic|Logic Gates;Information Technology:Programming|Database|Networking|Internet|Cybersecurity|Artificial Intelligence|ICT in Bangladesh",
  ),
  C(
    "BCS",
    "math",
    "Mathematical Reasoning",
    "গাণিতিক যুক্তি",
    15,
    "Arithmetic:Number System|LCM and GCD|Percentage|Ratio|Profit and Loss|Interest|Average|Age|Time and Work|Speed and Distance;Advanced Mathematics:Algebra|Geometry|Mensuration|Probability|Permutation and Combination|Statistics|Logarithms|Set Theory",
  ),
  C(
    "BCS",
    "mental",
    "Mental Ability",
    "মানসিক দক্ষতা",
    15,
    "Reasoning:Verbal Reasoning|Numerical Reasoning|Series|Analogy|Classification|Coding-Decoding|Direction|Blood Relations|Logical Sequence|Puzzles|Data Interpretation|Pattern Recognition",
  ),
  C(
    "BCS",
    "ethics",
    "Ethics and Good Governance",
    "নৈতিকতা ও সুশাসন",
    10,
    "Principles:Ethics|Values|Morality|Good Governance|Accountability|Transparency|Rule of Law|Human Rights|Citizenship|Administrative Ethics",
  ),
  C(
    "EEE",
    "circuits",
    "Electrical Circuit Analysis",
    "বৈদ্যুতিক সার্কিট",
    0,
    "DC Circuits:Ohm's Law|Kirchhoff's Laws|Network Theorems|Thevenin's Theorem|Norton's Theorem|Superposition|Maximum Power Transfer|Mesh Analysis|Nodal Analysis;AC Circuits:AC Fundamentals|Phasors|Resonance|Three-Phase Circuits|Power Factor|Transient Analysis",
  ),
  C(
    "EEE",
    "machines",
    "Electrical Machines",
    "বৈদ্যুতিক মেশিন",
    0,
    "Static Machines:Transformer|Equivalent Circuits|Machine Testing;Rotating Machines:DC Generator|DC Motor|Induction Motor|Synchronous Generator|Synchronous Motor|Starting Methods|Speed Control|Losses|Efficiency|Torque-Speed Characteristics",
  ),
  C(
    "EEE",
    "power",
    "Power Systems",
    "বিদ্যুৎ ব্যবস্থা",
    0,
    "Power Networks:Generation|Transmission|Distribution|Load Flow|Fault Analysis|Symmetrical Components|Circuit Breakers|Protective Relays|Earthing|Power Factor Correction;System Operation:Stability|Economic Dispatch|HVDC|Smart Grid|Renewable Integration",
  ),
  C(
    "EEE",
    "electronics",
    "Power Electronics",
    "পাওয়ার ইলেকট্রনিক্স",
    0,
    "Devices:Power Diodes|SCR|MOSFET|IGBT|Gate Drivers;DC-DC Converter:Buck Converter|Boost Converter|Buck-Boost Converter|Choppers|SMPS;Conversion and Drives:Rectifiers|Controlled Rectifiers|Inverters|PWM|AC Voltage Controllers|Cycloconverters|DC Drives",
  ),
  C(
    "EEE",
    "control",
    "Control Systems",
    "কন্ট্রোল সিস্টেম",
    0,
    "Modeling:Open and Closed Loop Systems|Transfer Functions|Block Diagram Reduction|Signal Flow Graph|Time Response|State-Space Analysis;Analysis and Design:Stability|Routh-Hurwitz|Root Locus|Bode Plot|Nyquist Plot|PID Controllers|Compensators|Digital Control",
  ),
  C(
    "EEE",
    "measure",
    "Electrical Measurements",
    "বৈদ্যুতিক পরিমাপ",
    0,
    "Instrumentation:Ammeter|Voltmeter|Wattmeter|Energy Meter|Power Factor Meter|CT and PT|Instrument Transformers|Bridges|Calibration|Measurement Errors",
  ),
  C(
    "EEE",
    "digital",
    "Digital Electronics",
    "ডিজিটাল ইলেকট্রনিক্স",
    0,
    "Digital Logic:Number Systems|Boolean Algebra|Logic Gates|K-Maps|Combinational Circuits|Sequential Circuits|Flip-Flops|Counters|Registers|ADC and DAC|Microprocessors",
  ),
  C(
    "EEE",
    "analog",
    "Analog Electronics",
    "অ্যানালগ ইলেকট্রনিক্স",
    0,
    "Semiconductors:PN Junction|BJT|FET|MOSFET;Analog Circuits:Amplifiers|Operational Amplifiers|Oscillators|Feedback|Filters|Voltage Regulators",
  ),
  C(
    "EEE",
    "installation",
    "Electrical Installation and Utilization",
    "বৈদ্যুতিক ইনস্টলেশন",
    0,
    "Installation:Wiring|Cable Sizing|Electrical Safety|Protection Devices|Industrial Installation|Domestic Installation|Substations|Lighting|Electrical Estimation|Energy Auditing",
  ),
  C(
    "EEE",
    "renewable",
    "Renewable Energy",
    "নবায়নযোগ্য শক্তি",
    0,
    "Renewable Systems:Solar PV|Solar Cell Characteristics|MPPT|Battery Systems|Wind Energy|Hybrid Systems|Grid-Connected Inverters|Energy Storage",
  ),
  C(
    "EEE",
    "micro",
    "Microprocessor and Microcontroller",
    "মাইক্রোপ্রসেসর ও মাইক্রোকন্ট্রোলার",
    0,
    "Embedded Systems:Architecture|Memory and I/O|Interrupts|Timers|Serial Communication",
  ),
  C(
    "EEE",
    "engmath",
    "Engineering Mathematics",
    "প্রকৌশল গণিত",
    0,
    "Applied Mathematics:Complex Numbers|Differential Equations|Laplace Transform|Matrices|Calculus",
  ),
  C(
    "EEE",
    "physics",
    "General Physics",
    "সাধারণ পদার্থবিজ্ঞান",
    0,
    "Fundamentals:Mechanics|Waves|Electromagnetism|Thermodynamics",
  ),
  C(
    "EEE",
    "techeng",
    "Technical English",
    "কারিগরি ইংরেজি",
    0,
    "Communication:Technical Vocabulary|Comprehension|Grammar and Usage",
  ),
  C(
    "EEE",
    "genict",
    "General Knowledge and ICT",
    "সাধারণ জ্ঞান ও তথ্যপ্রযুক্তি",
    0,
    "General Preparation:Bangladesh Affairs|Current Affairs|ICT Fundamentals|Computer Networks",
  ),
];
export const sample = [];
function Q(
  subject,
  subtopic,
  text,
  options,
  answer,
  explanation,
  difficulty = "Easy",
) {
  const s = syllabus.find((x) => x.id === subject);
  sample.push({
    id: `practice-${sample.length + 1}`,
    track: s.track,
    subject,
    topic: Object.keys(s.groups).find((k) => s.groups[k].includes(subtopic)),
    subtopic,
    text,
    options,
    answer,
    explanation,
    difficulty,
    kind: "Original practice",
    source: "ExamPrep BD demo collection",
    status: "Sample",
  });
}
Q(
  "bangla",
  "সমাস",
  "‘রাজপুত্র’ কোন সমাসের উদাহরণ?",
  ["দ্বন্দ্ব", "ষষ্ঠী তৎপুরুষ", "বহুব্রীহি", "অব্যয়ীভাব"],
  1,
  "রাজার পুত্র → রাজপুত্র। ‘রাজার’ পদে ষষ্ঠী বিভক্তি লোপ পেয়েছে।",
);
Q(
  "bangla",
  "বাগধারা",
  "‘আকাশকুসুম’ বাগধারার অর্থ কী?",
  ["অসম্ভব কল্পনা", "অন্ধকার রাত", "অল্প সময়", "সুসংবাদ"],
  0,
  "‘আকাশকুসুম’ বলতে অবাস্তব বা অসম্ভব কল্পনা বোঝায়।",
);
Q(
  "english",
  "Preposition",
  "She is interested ___ electrical engineering.",
  ["on", "at", "in", "for"],
  2,
  "The adjective “interested” is followed by “in” when introducing the object of interest.",
);
Q(
  "english",
  "Preposition",
  "Who is responsible ___ the report?",
  ["with", "for", "in", "of"],
  1,
  "“Responsible for” introduces a duty or task.",
);
Q(
  "english",
  "Subject-Verb Agreement",
  "Which sentence is correct?",
  [
    "Each student have a book.",
    "The books is new.",
    "Neither answer is correct.",
    "She go to class.",
  ],
  2,
  "“Neither answer” is singular, so it takes “is”.",
);
Q(
  "english",
  "Shakespeare",
  "Who wrote Macbeth?",
  ["John Milton", "Charles Dickens", "William Shakespeare", "Jane Austen"],
  2,
  "Macbeth is a tragedy by William Shakespeare.",
);
Q(
  "english",
  "Article",
  "Choose the article: He wears ___ uniform.",
  ["a", "an", "the only", "some"],
  0,
  "“Uniform” starts with the consonant sound /j/, so the indefinite article is “a”.",
);
Q(
  "bangladesh",
  "Constitution",
  "On which date did the Constitution of Bangladesh come into force?",
  ["26 March 1971", "16 December 1972", "4 November 1972", "21 February 1952"],
  1,
  "The Constitution was adopted on 4 November 1972 and entered into force on 16 December 1972.",
);
Q(
  "bangladesh",
  "Language Movement",
  "International Mother Language Day is observed on which date?",
  ["16 December", "26 March", "21 February", "14 April"],
  2,
  "International Mother Language Day is observed on 21 February.",
);
Q(
  "bangladesh",
  "Liberation War 1971",
  "When is Victory Day observed in Bangladesh?",
  ["16 December", "26 March", "21 February", "1 May"],
  0,
  "Bangladesh observes Victory Day on 16 December, commemorating the surrender in 1971.",
);
Q(
  "international",
  "United Nations",
  "Which UN organ has permanent members with veto powers on substantive decisions?",
  [
    "General Assembly",
    "Security Council",
    "Secretariat",
    "International Court of Justice",
  ],
  1,
  "The five permanent members of the Security Council can veto substantive decisions.",
);
Q(
  "geography",
  "Climate",
  "Which describes climate rather than weather?",
  [
    "Rain this morning",
    "Wind speed now",
    "Long-term rainfall patterns",
    "Tomorrow’s temperature",
  ],
  2,
  "Climate describes long-term patterns, while weather describes short-term conditions.",
);
Q(
  "science",
  "Human Body",
  "Which cells transport most oxygen in human blood?",
  ["Platelets", "Red blood cells", "Neurons", "White blood cells"],
  1,
  "Hemoglobin in red blood cells binds oxygen for transport.",
);
Q(
  "science",
  "Chemistry",
  "What is the pH of pure water at 25 °C?",
  ["0", "5", "7", "14"],
  2,
  "Pure water is neutral at 25 °C, with a pH of approximately 7.",
);
Q(
  "ict",
  "Logic Gates",
  "Which gate outputs 1 only when both of its two inputs are 1?",
  ["OR", "XOR", "NAND", "AND"],
  3,
  "A two-input AND gate is 1 only for the input pair (1, 1).",
);
Q(
  "mental",
  "Series",
  "What is the next term: 3, 6, 12, 24, …?",
  ["30", "36", "48", "52"],
  2,
  "Each term is twice the previous one, so 24 × 2 = 48.",
);
Q(
  "ethics",
  "Transparency",
  "Which practice best supports public-sector transparency?",
  [
    "Publishing procurement criteria",
    "Hiding all evaluation rules",
    "Removing audit trails",
    "Disclosing only winning bidders’ names",
  ],
  0,
  "Publishing criteria gives the public visibility into how bids are evaluated.",
);
for (const [i, n] of [80, 120, 160, 180, 240, 320, 360, 400].entries()) {
  const p = 10 + i * 5,
    a = (n * p) / 100;
  const o = [a + 5, a - 3, a, a + 10];
  Q(
    "math",
    "Percentage",
    `What is ${p}% of ${n}?`,
    o.map(String),
    2,
    `Multiply by the percentage as a fraction: ${n} × ${p}/100 = ${a}.`,
  );
}
for (const [i, r] of [2, 3, 4, 5, 6, 8, 10, 12, 15, 20].entries()) {
  const a = i + 2,
    v = a * r;
  Q(
    "circuits",
    "Ohm's Law",
    `A ${r} Ω resistor has ${v} V across it. What current flows through it?`,
    [a + 1, a, a + 3, a - 1].map((x) => `${x} A`),
    1,
    `Ohm’s law gives I = V/R = ${v} V ÷ ${r} Ω = ${a} A.`,
  );
}
for (const [i, n] of [100, 150, 200, 250, 300, 350, 400, 450].entries()) {
  const p = n * (i + 2),
    s = 120 * (i + 2);
  Q(
    "machines",
    "Transformer",
    `An ideal transformer has ${p} primary and ${n} secondary turns. If the secondary voltage is 120 V RMS, what is the primary voltage?`,
    [s, s + 60, s - 60, s + 120].map((x) => `${x} V`),
    0,
    `Vₚ/Vₛ = Nₚ/Nₛ = ${p}/${n}. Therefore Vₚ = 120 × ${i + 2} = ${s} V RMS.`,
    "Medium",
  );
}
for (const [i, v] of [24, 48, 60, 72, 84, 96, 108, 120].entries()) {
  const d = ((i % 3) + 1) / 4,
    a = v * d;
  Q(
    "electronics",
    "Buck Converter",
    `An ideal buck converter in continuous conduction takes ${v} V DC at a duty ratio of ${d}. What is its average output voltage?`,
    [a + 2, a + 5, a + 10, a].map((x) => `${x} V`),
    3,
    `For an ideal buck converter, Vout = D × Vin = ${d} × ${v} = ${a} V.`,
    "Medium",
  );
}
Q(
  "power",
  "Fault Analysis",
  "What is a balanced three-phase short circuit modeled with in symmetrical component analysis?",
  [
    "Zero sequence only",
    "Negative sequence only",
    "Positive sequence only",
    "All three sequences in series",
  ],
  2,
  "A balanced three-phase fault preserves phase symmetry, so only the positive-sequence network contributes.",
  "Medium",
);
Q(
  "power",
  "Earthing",
  "What is a key purpose of protective earthing?",
  [
    "Increasing load current in normal operation",
    "Providing a fault-current path",
    "Eliminating all voltage drops",
    "Increasing supply frequency",
  ],
  1,
  "Protective earthing provides a fault-current path so protection can disconnect the faulty circuit.",
);
Q(
  "control",
  "Stability",
  "Where must all poles of a causal continuous-time rational transfer function lie for BIBO stability?",
  [
    "Open right half-plane",
    "On the imaginary axis",
    "Open left half-plane",
    "At the origin",
  ],
  2,
  "All transfer-function poles must have strictly negative real parts for the impulse response to be absolutely integrable.",
  "Medium",
);
Q(
  "measure",
  "Ammeter",
  "How is an ideal ammeter connected to measure branch current?",
  [
    "In parallel with the branch",
    "In series with the branch",
    "Across earth and neutral",
    "Inductively only",
  ],
  1,
  "An ammeter is placed in series so the branch current flows through it.",
);
Q(
  "analog",
  "Operational Amplifiers",
  "What is the ideal op-amp input current?",
  ["Zero", "1 A", "Equal to output current", "Supply voltage divided by gain"],
  0,
  "An ideal op-amp has infinite input impedance, so its input current is zero.",
);
Q(
  "digital",
  "Logic Gates",
  "A two-input XOR gate is high when its inputs are:",
  ["Both low", "Both high", "Different", "Always high"],
  2,
  "XOR outputs high if exactly one input is high.",
);
Q(
  "renewable",
  "MPPT",
  "What does MPPT aim to maximize in a PV system?",
  [
    "PV cable length",
    "PV array output power",
    "Battery weight",
    "Grid frequency",
  ],
  1,
  "Maximum power point tracking adjusts the operating point to maximize power extracted from the PV array.",
);
