export const intervals = [1, 3, 7, 15, 30];
export const day = (date = new Date()) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Dhaka",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
export const limitInt = (v, min, max, fallback = min) => {
  const n = Number(v);
  return Number.isInteger(n) && n >= min && n <= max ? n : fallback;
};
export const priority = (values, weights) => {
  const allowed = values
    .map((x, i) => [x, Number(weights[i])])
    .filter(([x, w]) => x != null && Number.isFinite(w) && w > 0);
  const total = allowed.reduce((a, [, w]) => a + w, 0);
  return total
    ? Math.round(
        allowed.reduce(
          (a, [x, w]) => a + Math.max(0, Math.min(100, x)) * w,
          0,
        ) / total,
      )
    : null;
};
export function selectExam(
  rows,
  { count, mode, track, subjects, distribution },
) {
  const pool = [...rows];
  if (mode === "mock" && track === "BCS") {
    if (subjects.reduce((n, x) => n + x.marks, 0) !== 200)
      throw Error(
        "The BCS mark distribution must total 200. Update the syllabus before starting a full mock.",
      );
    return subjects.flatMap((s) => {
      const available = pool.filter((x) => x.subject === s.id);
      if (available.length < s.marks)
        throw Error(
          `${s.name} needs ${s.marks} questions for the full mock; ${available.length} are available.`,
        );
      return available.slice(0, s.marks);
    });
  }
  if (pool.length < count)
    throw Error(
      `Only ${pool.length} matching questions are available. Adjust the filters or lower the question count.`,
    );
  if (mode === "daily") {
    const first = pool.shift(),
      second = pool.findIndex(
        (x) =>
          x.subject !== first.subject &&
          (track !== "Both" || x.track !== first.track),
      );
    if (second < 0)
      throw Error(
        track === "Both"
          ? "A combined daily exam needs questions from both tracks."
          : "A daily exam needs at least two subjects in the question pool.",
      );
    const chosen = [first, ...pool.splice(second, 1)];
    if (distribution) {
      const buckets = [
        "High priority",
        "Medium priority",
        "Revision",
        "Weak topics",
        "Previous-year",
      ];
      const quotas = distribution.map((n, i) => ({
        i,
        value: (n * (count - 2)) / 100,
        n: Math.floor((n * (count - 2)) / 100),
      }));
      const spare = count - 2 - quotas.reduce((a, q) => a + q.n, 0);
      for (const q of [...quotas]
        .sort((a, b) => b.value - b.n - (a.value - a.n))
        .slice(0, spare))
        q.n++;
      for (const { i, n } of [...quotas].reverse())
        for (let j = 0; j < n; j++) {
          const index = pool.findIndex((q) => q.buckets?.includes(buckets[i]));
          if (index < 0) break;
          chosen.push(...pool.splice(index, 1));
        }
    }
    return [...chosen, ...pool.slice(0, count - chosen.length)];
  }
  return pool.slice(0, count);
}
export function grade(questions, answers, penalty) {
  let correct = 0,
    incorrect = 0,
    unanswered = 0;
  const rows = questions.map((q, i) => {
    const a = answers[i];
    let outcome = "Unanswered";
    if (a?.choice == null) unanswered++;
    else if (a.choice === q.answer) {
      outcome = "Correct";
      correct++;
    } else {
      outcome = "Incorrect";
      incorrect++;
    }
    return {
      ...q,
      choice: a?.choice ?? null,
      outcome,
      seconds: a?.seconds ?? 0,
    };
  });
  return {
    correct,
    incorrect,
    unanswered,
    score: Math.round((correct - incorrect * Number(penalty)) * 100) / 100,
    accuracy:
      correct + incorrect
        ? Math.round((100 * correct) / (correct + incorrect))
        : 0,
    rows,
  };
}
